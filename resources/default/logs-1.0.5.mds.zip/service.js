// Keep at most one day of logs, and never more than this many rows.
var MAX_AGE_SECONDS = 86400;
var MAX_ROWS = 20000;

function purge() {

  // Delete anything older than MAX_AGE_SECONDS.
  // NOTE: do NOT write `CURRENT_TIMESTAMP - 86400`. H2 reads a bare number subtracted from a
  // timestamp as DAYS, not seconds, which is why the previous `- 604800` resolved to the year
  // 0370, silently matched no rows, and let the table grow forever.
  MDS.sql(`DELETE FROM logs WHERE timestamp <= DATEADD('SECOND',-${MAX_AGE_SECONDS},CURRENT_TIMESTAMP)`);

  // Hard row cap as a backstop, so the table stays bounded however chatty the node is.
  MDS.sql(`DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT ${MAX_ROWS})`);
}

MDS.init(function (msg) {
  if (msg.event === 'inited') {

    // create schema
    MDS.sql('CREATE TABLE IF NOT EXISTS logs (id bigint auto_increment,message varchar(2048) NOT NULL,timestamp TIMESTAMP)');

    // purge on startup as well as hourly, so an upgraded node cleans up immediately
    // instead of waiting for the first MDS_TIMER_1HOUR an hour after MDS starts
    purge();

  } else if (msg.event === 'MINIMALOG') {
    var encoded = encodeURIComponent(msg.data.message).replace(/'/g, "%27");

    if (encoded.length >= 2032) {
      encoded = encoded.slice(0, 2032) + '...';
    }

    // insert logs into the logs table
    MDS.sql(`INSERT INTO logs (message,timestamp) VALUES ('${encoded}',CURRENT_TIMESTAMP)`, function (response) {});

  } else if (msg.event === 'MDS_TIMER_1HOUR') {

    //Delete every hour..
    purge();
  }
});
