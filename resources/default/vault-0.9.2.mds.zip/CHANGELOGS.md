##### [0.8.4] - 28 November 23

- Updated source code
- Added tailwindcss
- Updated home page
- New icons

##### [0.9.1] - 06 December 23

- Fix callback on Pending dialog
- Add error message on error dialog
- Re-enable Create Vault button on error