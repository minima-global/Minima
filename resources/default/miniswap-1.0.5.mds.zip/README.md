# Miniswap

Miniswap is a decentralized exchange built on top of the Minima blockchain. It allows users to swap one cryptocurrency for another in a trustless and decentralized manner.

## Getting Started

To use Miniswap, you will need to have a Minima wallet set up. You can download the Minima wallet from the official Minima website at https://minima.global.

Once you have a Minima wallet set up, you can connect it to Miniswap by following these steps:

`java -jar minima.jar -mdsenable`

then type `mds` after minima loads.

You will see something like this

```
{
  "command":"mds",
  "status":true,
  "pending":false,
  "response":{
    "enabled":true,
    "connect":"https://xxx.xx.x.xx:9003",
    "password":"123",
    "minidapps":[]
  }
}
```

Copy the `https://xxx.xx.x.xx:9003` into a browser, and ignore the browser security warning.

Zip the contents of the miniswap folder, and upload that to the webpage.

Set the permissions of the minidapp to `write mode` in the web page.

You are ready to go.

## Features

Miniswap has the following features:

-   Trustless and decentralized exchange of cryptocurrencies
-   No need for a centralized intermediary
-   Low transaction fees
-   Fast transaction times
-   Simple and easy-to-use interface

#### Build mds
- use -x .git to exclude git hidden folder 
zip -r miniswap-1.0.6.mds.zip -x \*.git\*


License
Miniswap is licensed under the MIT license.
