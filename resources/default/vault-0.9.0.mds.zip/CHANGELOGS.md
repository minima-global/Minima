##### [0.8.4] - 28 November 23

- Updated source code
- Added tailwindcss
- Updated home page
- New icons