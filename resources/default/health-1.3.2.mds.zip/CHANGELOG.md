# Changelog

##### [1.3.2] - 3rd of March 25

- The MiniDapp has been renamed back to 'Health'

##### [1.3.1] - 28th of February 25

- Minor text changes

##### [1.3.0] - 27th of February 25

- Revised some of the UI

##### [1.2.3] - 18th of February 25

- The MiniDapp has been renamed to 'Status'

##### [1.2.2] - 22nd of January 25

- Changed category to System

##### [1.2.1] - 16th of January 25

- Made network data backwards compatible with Minima nodes older than 1.44.3

##### [1.2.0] - 14th of January 25

- Fixed network data on Minima nodes newer than 1.44.3

##### [1.1.5] - 12 September 23

- Minor text changes

##### [1.1.4] - 9th of August

- Minor text changes

##### [1.1.2] - 1st of August

- Minor text changes

##### [1.1.1] - 31st of July

- Minor text changes

##### [1.1.0] - 24 July 23

- Minor text changes
- Added poll count as a stat

##### [1.0.3] - 24 July 23

- Minor text changes

##### [0.2.1] - 14 June 23

- Fixed network counts

##### [0.1.8] - 13 June 23

- Added Android.showTitleBar support

##### [0.1.5] - 12 June 23

- Fixed chain status logic
