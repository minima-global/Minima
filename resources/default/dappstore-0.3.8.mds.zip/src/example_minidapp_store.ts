export const exampleMiniDappStoreJson = {
  "name": "",
  "description": "",
  "banner": "https://",
  "icon": "https://",
  "version": "1.0",
  "manifest_version": 2,
  "dapps": [
    {
      "file": "https://",
      "icon": "https://",
      "name": "Script IDE",
      "date": "Jul 24, 2023",
      "description": "Minima Test Minidapp",
      "repository_url": "(optional)https://",
      "version": "1.0.0",
      "about": "...",
      "screenshots": [
        "https://image_width_240_x_image_height_320",
        "https://image_width_240_x_image_height_320"
      ],
      "release_notes": "#markdown",
      "history": [
        {
          "version": "1.0.0",
          "date": "Jan 01, 2023",
          "file": "(optional)https://",
          "release_notes": "#markdown"
        }
      ]
    },
    {
      "file": "https//",
      "icon": "https://",
      "name": "...",
      "date": "Jul 24, 2023",
      "description": "...",
      "version": "1.0.0",
      "about": "...",
      "screenshots": null,
      "update": null,
      "history": null
    }
  ],
};
