/// <reference types="vite/client" />

declare const MDS: any;
