# Changelog

##### [0.1.0] - 08 November 23

- Initial Skeleton

##### [0.22.2] - 08 Jan 25

- depositing Minima splits 10 on marketplace wallet
- fixed default nft image if empty url
- added token id to the listings
- minor design tweaks

##### [0.23.0] - 15 Jan 25

- Updated brand name & icon 

##### [0.25.0] - 27 Jan 25

- Set default sorting on Market view
- Avatar design tweaks in Sellers page and Global feed

##### [0.3.0] - 28 Jan 25

- Fix /sql file not found cli error

##### [0.4.0] - 30 Jan 25

- Added terms & conditions

##### [0.4.1] - 30 Jan 25

- Updated line-height on intro

##### [0.5.0] - 26 Feb 25

- Made Global Activity feed interactive (click on profile to open profile, nft to open listing)
- Added Mx address & public key to profile
- Fixed bug where user could not click, drag and copy on the listing page
 
##### [0.6.0] - 27 Feb 25

- Added Manrope font

