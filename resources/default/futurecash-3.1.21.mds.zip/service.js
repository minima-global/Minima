/**
 * Future Cash (next) — shared guardian core (PURE ES5, CALLBACK STYLE).
 *
 * The Minima service worker runs in an ES5 engine (Nashorn/Rhino). NO async/await, Promise,
 * Set, arrow functions, let/const or template literals — any of them makes service.js fail to
 * parse and the daemon never starts. Everything here is plain ES5 with callbacks.
 *
 * Loaded by BOTH contexts:
 *   - service.js — this file is CONCATENATED with svc-main.js at build time (build.sh).
 *   - index.html — via <script src="guardian.js">; ui.js calls these callback APIs.
 *
 * WHAT IT DOES (the WOTS-safe FutureCash):
 *   A collect is pinned by the contract: VERIFYOUT forces the funds to the pre-committed payout
 *   address held in state port 2, so a collect can only ever pay that address. COLLECT is therefore
 *   always WOTS-safe. The danger is only that the funds then sit on a payout address whose WOTS
 *   leaf key was REUSED (signed >=2 times => no longer safe). This guardian:
 *     - audits the node's keys (the UI page runs the KeyUses audit and writes the at-risk address
 *       set to keypair `atrisk_addrs`);
 *     - detects your matured/maturing FutureCash coins;
 *     - SAFE payout (not reused): just COLLECT (funds land safely) when you opt in;
 *     - AT-RISK payout (reused): COLLECT then immediately SWEEP the collected coin to a safe
 *       external address (one signed txn, racing any attacker), verifying it landed.
 *
 * State model: MDS.keypair = shared config/status/log between service + page. MDS.sql = the
 * daemon's own work tables (fc_collect / fc_sweep), read+written in the service context.
 */

/* ----- Constants ----- */
var FCSCRIPT = "RETURN (@BLOCK GTE PREVSTATE(1) OR @COINAGE GTE PREVSTATE(4)) AND VERIFYOUT(@INPUT PREVSTATE(2) @AMOUNT @TOKENID FALSE)";
var SWEEP_CONFIRM_DEPTH = 0;   // sweep the instant the collected coin is sendable — minimal time on the exposed key
var RETRY_BLOCKS        = 8;   // a *_POSTED coin still unspent this long => re-try
var MAX_ATTEMPTS        = 5;   // after this many failed posts, raise a one-time alarm (never give up)
var VERIFY_GRACE        = 3;   // after the collected coin is spent, blocks to keep looking for OUR output at safe
var VERIFY_MAX          = 30;  // if the safe lookup stays unreliable this long, record swept-but-unverified
var MIN_DEFAULTS_KEEP   = 8;   // never retire so many default addresses that the node's change pool
                               // (Wallet.getDefaultAddress = a random pick) could hit zero and throw,
                               // breaking every change-making txn. Restart refills the pool to 64.
var LOG_MSG_MAX         = 300; // Activity-log line cap. It clips the TAIL, so any line that carries both
                               // a full coinid/address and an unbounded node error must put the ids
                               // FIRST — otherwise a long error truncates away the pasteable value.
var AUDIT_FRESH_MS      = 30 * 60000; // a SAFE bare-collect requires a successful audit no older than this.
                               // Older/failed/never-run => the payout can't be TRUSTED safe, so we never
                               // bare-collect onto it; if rescue is configured we sweep it (fail-safe), else wait.

// Known FutureCash / Maximize contract address (matured collections land here) — scanned directly
// as a backup to deriving the address from the script string.
var KNOWN_FC_ADDRESSES = ["0xEA8823992AB3CEBBA855D68006F0D05B0C4838FE55885375837D90F98954FA13"];

/* ----- Module state ----- */
var g_busy = false;
var g_busyAt = 0;
var g_seq = 0;
var notifyOn = true;
var g_fcCoins = {};
var g_tablesReady = false;
var g_vaultLocked = false;
var g_lockNotified = false;
var g_atRisk = {};      // canonAddr -> true, the at-risk payout addresses (from the page audit)
var g_safeMode = "external"; // "external" (a different wallet) or "samenode" (a fresh clean addr on THIS node)

/* ----- ES5 helpers ----- */
function nowMs() { return (Date && Date.now) ? Date.now() : new Date().getTime(); }
function isArr(a) { return Object.prototype.toString.call(a) === "[object Array]"; }
function errMsg(e) { return (e && e.message) ? e.message : ("" + e); }
function looksLikeVaultLockError(msg) { return /password|vault|unlock/i.test(String(msg || "")); }
function q(s) { return "'" + String(s == null ? "" : s).replace(/'/g, "''") + "'"; }
function toInt(v) { var n = parseInt(v, 10); return isNaN(n) ? 0 : n; }
function parseNum(v) { if (v == null) return null; var n = Number(v); return isNaN(n) ? null : n; }
function short(s) { s = String(s == null ? "" : s); return s.length > 14 ? s.slice(0, 8) + "…" + s.slice(-4) : s; }
function tokLabel(t) { return (t === "0x00") ? "MINIMA" : short(t); }
function txid(kind) { g_seq = (g_seq + 1) % 1000000; return "FC" + kind + nowMs() + "_" + g_seq; }
function isMinima(t) { return t === "0x00"; }
function canonAddr(a) {
  a = String(a == null ? "" : a).trim();
  if (/^0x/i.test(a)) return "h" + a.slice(2).toLowerCase();
  if (/^M[xX]/.test(a)) return "m" + a;
  if (/^[0-9a-fA-F]{8,}$/.test(a)) return "h" + a.toLowerCase();
  return "x" + a.toLowerCase();
}
function validMx(s) { return /^M[xX][0-9A-Za-z]{30,100}$/.test(String(s || "")); }
function coinOutAmount(coin) { return isMinima(coin.tokenid) ? coin.amount : coin.tokenamount; }
function getState(coin, port) {
  try { var v = MDS.util.getStateVariable(coin, port); if (v !== undefined && v !== null) return v; } catch (e) {}
  if (coin && isArr(coin.state)) {
    for (var i = 0; i < coin.state.length; i++) {
      var st = coin.state[i];
      if (st && (st.port == port || String(st.port) === String(port))) return st.data;
    }
  }
  return undefined;
}
// Trampolined: a synchronous next() (common — most items short-circuit) unwinds to the while loop
// instead of recursing, so a large coin set (hundreds/thousands, mostly skipped) can't overflow the
// Rhino service stack. An async next() stops the loop and resumes it when the callback fires.
function eachSeries(arr, iter, done) {
  if (!isArr(arr)) { if (done) done(); return; }
  var i = 0, inLoop = false, sync = false;
  function next() {
    if (inLoop) { sync = true; return; }   // called synchronously from iter → flag, let the loop advance
    inLoop = true;
    while (true) {
      if (i >= arr.length) { inLoop = false; if (done) done(); return; }
      var idx = i; i++;
      sync = false;
      try { iter(arr[idx], idx, next); } catch (e) { try { MDS.log("[FutureCash][error] eachSeries iter threw: " + errMsg(e)); } catch (x) {} sync = true; }
      if (!sync) { inLoop = false; return; }   // iter went async → its next() will resume the loop
    }
  }
  next();
}

/* ----- Low-level MDS wrappers ----- */
function mcmd(command, cb) {
  try { MDS.cmd(command, function (res) { cb(res); }); }
  catch (e) { cb({ status: false, error: errMsg(e) }); }
}
function msql(sql, cb) {
  try { MDS.sql(sql, function (res) { cb(res); }); }
  catch (e) { cb({ status: false }); }
}

/* ----- Cross-context config (MDS.keypair) ----- */
function cfgGet(k, dflt, cb) {
  try {
    MDS.keypair.get(k, function (r) {
      if (r && r.status && r.value !== undefined && r.value !== null && r.value !== "") cb(r.value);
      else cb(dflt === undefined ? null : dflt);
    });
  } catch (e) { cb(dflt === undefined ? null : dflt); }
}
function cfgSet(k, v, cb) {
  try { MDS.keypair.set(k, (v == null ? "" : "" + v), function () { if (cb) cb(); }); }
  catch (e) { if (cb) cb(); }
}
function logMsg(level, msg, cb) {
  try { MDS.log("[FutureCash][" + level + "] " + msg); } catch (e) {}
  cfgGet("fc_log", "[]", function (raw) {
    var arr = []; try { arr = JSON.parse(raw); } catch (e) { arr = []; }
    if (!isArr(arr)) arr = [];
    arr.unshift({ ts: nowMs(), level: level, msg: String(msg).slice(0, LOG_MSG_MAX) });
    if (arr.length > 80) arr = arr.slice(0, 80);
    cfgSet("fc_log", JSON.stringify(arr), function () { if (cb) cb(); });
  });
}

/* ----- The at-risk set (written by the page audit) ----- */
function loadAtRisk(cb) {
  cfgGet("atrisk_addrs", "[]", function (raw) {
    var arr = []; try { arr = JSON.parse(raw); } catch (e) { arr = []; }
    g_atRisk = {};
    if (isArr(arr)) for (var i = 0; i < arr.length; i++) { if (arr[i]) g_atRisk[canonAddr(arr[i])] = true; }
    // ALSO flag the node's own RETIRED addresses (script-row key nulled to 0x00) as at-risk. The page
    // audit only checks the 64 DEFAULT addresses, so a retired (non-default) reused address is invisible
    // to it — a stake paying out there would be bare-collected onto a reused (at-risk) address the guardian
    // then can't auto-sweep. Flagging forces the rescue path (collect + explicit-key sweep to the safe).
    retiredAddrs(function (rlist) {
      for (var j = 0; j < rlist.length; j++) if (rlist[j]) g_atRisk[canonAddr(rlist[j])] = true;
      cfgGet("safe_mode", "external", function (m) { g_safeMode = (m === "samenode") ? "samenode" : "external"; cb(); });
    });
  });
}
function isAtRisk(addr) { return !!(addr && g_atRisk[canonAddr(addr)] === true); }

/* ----- Status snapshot for the UI ----- */
function writeStatus(tip, cb) {
  countByStatus("fc_collect", function (c) {
    countByStatus("fc_sweep", function (s) {
      // Ready-to-act sums (matured, not yet posted), split safe vs at-risk.
      msql("SELECT at_risk, COUNT(*) AS N, SUM(CAST(out_amount AS DOUBLE)) AS A FROM fc_collect WHERE status='DETECTED' AND mature_block>0 AND mature_block<=" + toInt(tip) + " AND tokenid='0x00' GROUP BY at_risk", function (rr) {
        var safeN = 0, safeA = 0, riskN = 0, riskA = 0, rows = (rr && rr.rows) || [];
        for (var i = 0; i < rows.length; i++) {
          if (toInt(rows[i].AT_RISK) === 1) { riskN = toInt(rows[i].N); riskA = parseNum(rows[i].A) || 0; }
          else { safeN = toInt(rows[i].N); safeA = parseNum(rows[i].A) || 0; }
        }
        // Pending at-risk stakes (not yet matured) so the Guardian tab can show what's coming.
        msql("SELECT COUNT(*) AS N, MIN(mature_block) AS M, SUM(CAST(out_amount AS DOUBLE)) AS A FROM fc_collect WHERE status='DETECTED' AND at_risk=1 AND mature_block>" + toInt(tip) + " AND tokenid='0x00'", function (pr) {
          var prow = (pr && pr.rows && pr.rows[0]) || {};
          cfgSet("fc_status", JSON.stringify({
            lastTip: tip,
            watching: (c.DETECTED || 0),
            collecting: (c.COLLECT_POSTED || 0) + (c.COLLECT_POSTED_SAFE || 0),
            collectedSafe: (c.COLLECTED_SAFE || 0),
            collected: (c.COLLECTED || 0) + (c.SWEEP_QUEUED || 0),
            sweeping: (s.PENDING || 0) + (s.SWEEP_POSTED || 0),
            swept: (s.SWEPT || 0),
            taken: (s.TAKEN || 0),
            vaultLocked: g_vaultLocked,
            readySafeN: safeN, readySafeA: safeA, readyRiskN: riskN, readyRiskA: riskA,
            pendRiskN: toInt(prow.N), pendRiskSoonest: toInt(prow.M), pendRiskA: parseNum(prow.A) || 0,
            atRiskKnown: countKeys(g_atRisk)
          }), function () { if (cb) cb(); });
        });
      });
    });
  });
}
function countKeys(o) { var n = 0; for (var k in o) if (o.hasOwnProperty(k)) n++; return n; }

/* ----- Work tables ----- */
function ensureTables(cb) {
  msql("CREATE TABLE IF NOT EXISTS `fc_collect` (" +
    " `fc_coinid` varchar(80) PRIMARY KEY, `payout_address` varchar(80), `tokenid` varchar(80)," +
    " `out_amount` varchar(80), `mature_block` int DEFAULT 0, `at_risk` int DEFAULT 0," +
    " `status` varchar(24), `collect_block` int, `attempts` int DEFAULT 0," +
    " `updated` bigint, `note` varchar(256))", function () {
    msql("CREATE TABLE IF NOT EXISTS `fc_sweep` (" +
      " `coinid` varchar(80) PRIMARY KEY, `address` varchar(80), `tokenid` varchar(80)," +
      " `amount` varchar(80), `status` varchar(24), `sweep_block` int, `attempts` int DEFAULT 0," +
      " `updated` bigint, `note` varchar(256))", function () { if (cb) cb(); });
  });
}
function cleanScript(s) { return String(s || "").replace(/\s+/g, " ").trim(); }

// The contract address for the hot path (every reconcile): answered from the cache when we have
// one, otherwise resolved (and registered if genuinely absent) via registerFcScript. The cache is
// only ever trusted for the ADDRESS — never as evidence the script is still in the node's table.
// That assertion is registerFcScript's job and it runs at every boot.
function fcScriptAddress(cb) {
  cfgGet("script_address", null, function (cached) {
    if (cached) { cb(cached); return; }
    registerFcScript(cb);
  });
}
// Assert the contract script exists in THIS node's script table. Call this at every boot — never
// gated on the cached address. The cache lives in MDS keypair storage and the script lives in the
// node DB, so a node restored, re-synced or rebuilt keeps the cache and loses the script. Detection
// still worked (KNOWN_FC_ADDRESSES is hardcoded) and locking still worked (a send needs no script),
// so the gap only appeared at SPEND time: txnbasics attached no script, txnpost returned
// status:true, the chain rejected the transaction, and the collect retried forever in silence.
//
// We ASK THE NODE first and only run `newscript` when the script is really missing. `newscript` is
// NOT an idempotent no-op — core's newscript.java does wallet.removeScript() then wallet.addScript()
// as two separate synchronized calls, so re-registering an existing script briefly leaves the table
// with NO FutureCash script. The guardian posts collects concurrently on every NEWBLOCK, so a
// txnbasics landing in that window would attach no script — reproducing the exact bug this repair
// exists to fix. (Classic 2.7.1 re-registers blindly and gets away with it only because it has no
// background service.) Checking first keeps the table untouched on every healthy boot.
//
// The check is an ADDRESS lookup, not a script-text comparison. `clean:true` means the node stores
// the script as core's Contract.cleanScript re-emits it — a full re-tokenise with its own spacing
// and hex-case rules, NOT the whitespace collapse our cleanScript() does. Comparing text would
// therefore risk a false "missing" on every boot, putting us right back in the delete/re-add window.
// An address is exact, and the cached one came from the node itself. Text matching survives only as
// the first-run fallback, where a false miss just means one harmless newscript on an empty table.
//
// TRACKALL MUST STAY FALSE. Classic registers the identical script with trackall:false
// (maximize/futurecash_src/AppContext.tsx). Core keeps a coin (TxPoWTreeNode.checkRelevant) if its
// ADDRESS is tracked OR one of its STATE VARIABLES is a tracked address/key. The contract address is
// shared by every FutureCash and Maximize user alive, so tracking it makes EVERY stake on the chain
// relevant to this node — thousands of strangers' coins imported, rescanned every block, and one
// ownership-check bug away from being collected with the user's own burn. With trackall:false the
// address is not tracked, and a stake is kept only because state port 2 (its payout) is one of OUR
// addresses — which core tracks for us (Wallet.createNewKey adds them with track=true). That is
// exactly "my stakes only", and it is why classic cannot reach this state.
function registerFcScript(cb) {
  function cacheAndDone(a) {
    if (!a) { cb(null); return; }
    cfgGet("script_address", null, function (prev) {
      cfgSet("script_address", a, function () {
        if (prev === a) { cb(a); return; }   // already known — don't spend a log slot saying so
        logMsg("info", "FutureCash script address | address:" + a, function () { cb(a); });
      });
    });
  }
  // The ONLY path that writes the script table.
  function registerNow() {
    mcmd('newscript trackall:false clean:true script:"' + FCSCRIPT + '"', function (nr) {
      cacheAndDone((nr && nr.response && nr.response.address) ? nr.response.address : null);
    });
  }
  cfgGet("script_address", null, function (cached) {
    if (cached) {
      // A missing script is NOT an empty result: core's scripts.java throws "Script with that
      // address not found", so the lookup comes back status:false and scriptRowFor yields null.
      // Any other failure yields null too, which just costs one extra newscript — the right bias.
      scriptRowFor(cached, function (row) {
        // track=true is the 3.1.20-and-earlier registration, and it is a BUG (see TRACKALL above).
        // Repair it: newscript replaces the row, flipping the flag.
        if (row && row.track === true) {
          logMsg("warn", "Repairing contract registration — this node was tracking every FutureCash/Maximize stake on the chain, not just yours", function () { registerNow(); });
          return;
        }
        if (row) { cb(cached); return; }   // present and correctly scoped — touch nothing, log nothing
        registerNow();                     // cache survived a node restore that dropped the script
      });
      return;
    }
    // No cached address yet: the script may still be registered from an earlier install, so look for
    // it by text before adding one. A row left over from 3.1.20 carries track=true and needs the same
    // repair as the cached path.
    mcmd("scripts", function (sr) {
      var arr = (sr && isArr(sr.response)) ? sr.response : [];
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && cleanScript(arr[i].script) === cleanScript(FCSCRIPT)) {
          if (arr[i].track === true) { registerNow(); return; }
          cacheAndDone(arr[i].address); return;
        }
      }
      registerNow();
    });
  });
}

function getAddressSets(cb) {
  mcmd("scripts", function (r) {
    var arr = (r && isArr(r.response)) ? r.response : [];
    var ownDefault = {}, allTracked = {};
    for (var i = 0; i < arr.length; i++) {
      var s = arr[i];
      if (!s) continue;
      if (s.address) allTracked[s.address.toLowerCase()] = true;
      if (s.miniaddress) allTracked[s.miniaddress] = true;
      if (hasOwnKey(s)) {
        if (s.address) ownDefault[canonAddr(s.address)] = true;
        if (s.miniaddress) ownDefault[canonAddr(s.miniaddress)] = true;
      }
    }
    cb({ ownDefault: ownDefault, allTracked: allTracked });
  });
}
// Do WE hold the key for this script row — i.e. is it an address of ours rather than a contract?
//
// This must NOT be written as `s.default || s.publickey || ...`. Every custom script row carries the
// literal STRING "0x00" as its publickey (newscript.java passes it to wallet.addScript, ScriptRow
// .toJSON emits it), and "0x00" is truthy in JavaScript. That made every contract the node tracks —
// the FutureCash/Maximize contract itself, core's MULTISIG base, any contract another MiniDapp
// registered here — read as an address we own, so any chain-wide stake paying out to one of them
// passed the ownership gate and got collected with this user's burn. It also made the trailing
// `SIGNEDBY && !VERIFYOUT` clause dead code, since publickey short-circuited it every time.
function hasOwnKey(s) {
  if (!s) return false;
  if (s.default === true) return true;
  return !!(s.publickey && s.publickey !== "0x00");
}
function ownsAddress(ownObj, addr) { if (!addr) return false; return ownObj[canonAddr(addr)] === true; }

function addressIsLocal(addr, cb) {
  mcmd("scripts address:" + addr, function (r) {
    var arr = (r && isArr(r.response)) ? r.response : ((r && r.response && r.response.address) ? [r.response] : []);
    for (var i = 0; i < arr.length; i++) {
      if (hasOwnKey(arr[i])) { cb(true); return; }   // same "0x00" truthiness trap — see hasOwnKey
    }
    cb(false);
  });
}

function coinIsUnspent(coinid, cb) {
  mcmd("coins coinid:" + coinid, function (r) {
    if (!r || r.status !== true || !isArr(r.response)) { cb(true); return; }
    if (!r.response.length) { cb(false); return; }
    cb(!(r.response[0] && r.response[0].spent === true));
  });
}
function vaultLocked(cb) { mcmd("status", function (r) { var resp = (r && r.response) ? r.response : {}; cb(resp.locked === true); }); }
function rowExists(table, col, val, cb) {
  msql("SELECT " + col + " FROM " + table + " WHERE " + col + "=" + q(val) + " LIMIT 1", function (r) { cb(!!(r && r.status && r.rows && r.rows.length)); });
}

function buildAndPost(id, steps, cb) {
  var i = 0;
  function done(err) { mcmd("txndelete id:" + id, function () { cb(err); }); }
  function step() {
    if (i >= steps.length) { done(null); return; }
    var s = steps[i]; i++;
    mcmd(s, function (res) {
      var arr = isArr(res) ? res : [res];
      for (var j = 0; j < arr.length; j++) {
        var r = arr[j];
        if (r && r.pending) { done(new Error("pending — dapp is in READ mode")); return; }
        if (!r || !r.status) { done(new Error((r && r.error) || ("failed: " + s.split(" ")[0]))); return; }
      }
      step();
    });
  }
  step();
}
function markWriteConfirmed(isWrite, cb) { cfgSet("write_confirmed", isWrite ? "1" : "0", cb); }
// idPart is a full-value detail segment, e.g. "stake:0x…". It goes BEFORE the node's error text:
// logMsg clips the whole line at LOG_MSG_MAX, and an unbounded node error must never be what pushes
// the coinid out of the Activity log — that id is the one thing worth pasting from a failed post.
function handlePostError(e, what, idPart, cb) {
  var msg = errMsg(e);
  if (/pending|READ mode/i.test(msg)) {
    markWriteConfirmed(false, function () {
      logMsg("error", what + " is stuck as a PENDING request — Future Cash can't act unattended in READ mode. Switch it to WRITE in MiniHub. | " + idPart, function () { if (cb) cb(); });
    });
  } else { logMsg("error", what + " post failed | " + idPart + " — " + msg, function () { if (cb) cb(); }); }
}

/* ----- DETECT ----- */
function looksLikeFutureCash(c) {
  var payout = getState(c, 2), s1 = getState(c, 1);
  if (payout == null || payout === "" || s1 == null) return false;
  return /^[0-9]+$/.test(String(s1));   // port 1 must be a plain decimal block number
}

function detectFutureCash(tip, ownObj, fcAddrList, cb) {
  g_fcCoins = {};
  var processed = {};
  function handleCoin(c, idx, next) {
    if (!c || !c.coinid || processed[c.coinid] === true) { next(); return; }
    if (!looksLikeFutureCash(c)) { next(); return; }
    if (c.spent === true) { next(); return; }
    processed[c.coinid] = true;
    var payout = getState(c, 2);
    if (!ownsAddress(ownObj, payout)) { next(); return; }   // only stakes paying out to US
    g_fcCoins[c.coinid] = c;
    var matB = toInt(getState(c, 1));
    var risk = isAtRisk(payout) ? 1 : 0;
    rowExists("fc_collect", "fc_coinid", c.coinid, function (cexists) {
      if (cexists) {
        // Keep mature_block + at_risk fresh (the audit can flip at_risk between passes).
        msql("UPDATE fc_collect SET mature_block=" + matB + ", at_risk=" + risk + ", updated=" + nowMs() + " WHERE fc_coinid=" + q(c.coinid), function () {
          // REORG re-detect: this ORIGINAL FutureCash coin is unspent again (it reached here, and
          // spent coins are filtered out). If we'd recorded it collected, a reorg reversed the collect
          // — re-arm it so it gets collected/swept again instead of being stuck 'done'.
          msql("UPDATE fc_collect SET status='DETECTED', updated=" + nowMs() + " WHERE fc_coinid=" + q(c.coinid) + " AND (status='COLLECTED' OR status='COLLECTED_SAFE')", function () { next(); });
        });
      } else {
        var tok = c.tokenid, outAmt = coinOutAmount(c);
        msql("INSERT INTO fc_collect (fc_coinid,payout_address,tokenid,out_amount,mature_block,at_risk,status,collect_block,attempts,updated) VALUES (" +
          q(c.coinid) + "," + q(payout) + "," + q(tok) + "," + q(outAmt) + "," + matB + "," + risk + ",'DETECTED',0,0," + nowMs() + ")", function () {
          logMsg("info", "Detected FutureCash (" + outAmt + " " + tokLabel(tok) + ")" + (risk ? " [AT RISK]" : "") + " | stake:" + c.coinid + " | to:" + payout, function () { next(); });
        });
      }
    });
  }
  mcmd("coins relevant:true", function (r1) {
    var arr1 = (r1 && isArr(r1.response)) ? r1.response : [];
    eachSeries(arr1, handleCoin, function () {
      eachSeries(fcAddrList, function (sa, ai, nextAddr) {
        mcmd("coins address:" + sa, function (r2) {
          var arr2 = (r2 && isArr(r2.response)) ? r2.response : [];
          eachSeries(arr2, handleCoin, function () { nextAddr(); });
        });
      }, function () { cb(); });
    });
  });
}

function getFcScanAddresses(cb) {
  fcScriptAddress(function (derived) {
    var list = [], seen = {};
    function add(a) { if (a) { var k = String(a).toLowerCase(); if (!seen[k]) { seen[k] = true; list.push(a); } } }
    add(derived);
    for (var i = 0; i < KNOWN_FC_ADDRESSES.length; i++) add(KNOWN_FC_ADDRESSES[i]);
    cb(list);
  });
}

/* ----- COLLECT ----- */
// Collect matured coins, WOTS-safely:
//   - AT-RISK payout (audit says reused): collect only if rescue can immediately follow
//     (rescueEnabled + a usable safe address + unlocked vault) — then the coin is swept. Deferred
//     otherwise so funds never sit on the exposed key with no sweep behind them.
//   - SAFE payout AND a FRESH successful audit: bare-collect (lands safely, no sweep) if opted in.
//   - SAFE-classified but audit STALE/failed (can't trust it): LEAVE IT. An uncollected coin sits in
//     the contract, where it is not at risk at all — collecting is what moves funds ONTO the payout
//     address. So waiting for a fresh audit is strictly safer (and cheaper) than sweeping it to the
//     safe "just in case", which relocated fine funds off-node and burned a tx.
// A collect spends no key of ours (the contract pins the destination); the sweep is the only signature.
function collectMatured(tip, autoCollectSafe, rescueEnabled, auditFresh, canSweep, ownDefault, cb) {
  msql("SELECT * FROM fc_collect WHERE status='DETECTED'", function (r) {
    var rows = (r && r.rows) || [];
    eachSeries(rows, function (row, idx, next) {
      // Ownership is re-checked HERE, not just at detect time. Detection filters what goes IN, but a
      // row already in the table would otherwise stay actionable forever — and 3.1.20 and earlier
      // admitted stakes that were never ours (see hasOwnKey). Never post for a payout we don't own.
      if (!ownsAddress(ownDefault, row.PAYOUT_ADDRESS)) {
        msql("DELETE FROM fc_collect WHERE fc_coinid=" + q(row.FC_COINID), function () { next(); });
        return;
      }
      var coin = g_fcCoins[row.FC_COINID];
      if (!coin) {
        coinIsUnspent(row.FC_COINID, function (unspent) {
          if (!unspent) { msql("UPDATE fc_collect SET status='COLLECTED', updated=" + nowMs() + " WHERE fc_coinid=" + q(row.FC_COINID), function () { next(); }); }
          else next();
        });
        return;
      }
      var s1 = parseNum(getState(coin, 1)), s4 = parseNum(getState(coin, 4)), created = parseNum(coin.created);
      var matured = (s1 != null && tip >= s1) || (s4 != null && created != null && (tip - created) >= s4);
      if (!matured) { next(); return; }
      var atRisk = toInt(row.AT_RISK) === 1;
      // Decide: bare-collect (safe), collect-to-sweep (at-risk only), or defer.
      var bareCollectSafe = (!atRisk && auditFresh && autoCollectSafe);
      var collectToSweep = atRisk && rescueEnabled && canSweep;
      if (!bareCollectSafe && !collectToSweep) { next(); return; }   // can't act safely yet — leave DETECTED
      var postedStatus = bareCollectSafe ? "COLLECT_POSTED_SAFE" : "COLLECT_POSTED";
      msql("UPDATE fc_collect SET status='" + postedStatus + "', collect_block=" + toInt(tip) + ", attempts=attempts+1, updated=" + nowMs() + " WHERE fc_coinid=" + q(row.FC_COINID), function () {
        var id = txid("COL");
        buildAndPost(id, [
          "txncreate id:" + id,
          "txninput id:" + id + " coinid:" + coin.coinid,
          "txnoutput id:" + id + " address:" + row.PAYOUT_ADDRESS + " amount:" + row.OUT_AMOUNT + " tokenid:" + row.TOKENID + " storestate:false",
          "txnbasics id:" + id + ";txnpost id:" + id
        ], function (err) {
          if (!err) {
            markWriteConfirmed(true, function () {
              if (notifyOn) { try { MDS.notify("Future Cash: collecting matured " + row.OUT_AMOUNT + " " + tokLabel(row.TOKENID) + (bareCollectSafe ? "" : " — will sweep to safe")); } catch (e) {} }
              logMsg("info", "Collecting " + row.OUT_AMOUNT + " " + tokLabel(row.TOKENID) + (bareCollectSafe ? " [safe]" : " [rescue]") + " | stake:" + row.FC_COINID + " | to:" + row.PAYOUT_ADDRESS, function () { next(); });
            });
          } else { handlePostError(err, "Collect", "stake:" + row.FC_COINID + " | to:" + row.PAYOUT_ADDRESS, function () { next(); }); }
        });
      });
    }, function () { cb(); });
  });
}

function reconcileCollects(tip, cb) {
  msql("SELECT * FROM fc_collect WHERE status='COLLECT_POSTED' OR status='COLLECT_POSTED_SAFE'", function (r) {
    var rows = (r && r.rows) || [];
    eachSeries(rows, function (row, idx, next) {
      // Terminal is derived from the LIVE at_risk column, not just the posted status: a coin
      // bare-collected as SAFE that a fresh audit has since flipped to at-risk (at_risk=1) must NOT
      // finish as terminal-safe — route it to COLLECTED so it gets swept off the exposed address.
      var safe = (row.STATUS === "COLLECT_POSTED_SAFE") && (toInt(row.AT_RISK) === 0);
      coinIsUnspent(row.FC_COINID, function (unspent) {
        if (!unspent) {
          var doneStatus = safe ? "COLLECTED_SAFE" : "COLLECTED";
          msql("UPDATE fc_collect SET status='" + doneStatus + "', updated=" + nowMs() + " WHERE fc_coinid=" + q(row.FC_COINID), function () {
            if (safe && notifyOn) { try { MDS.notify("Future Cash: collected " + row.OUT_AMOUNT + " " + tokLabel(row.TOKENID) + " safely"); } catch (e) {} }
            logMsg("info", "Collected " + row.OUT_AMOUNT + " " + tokLabel(row.TOKENID) + (safe ? " [safe]" : " [rescue → sweeping next]") + " | stake:" + row.FC_COINID + " | on:" + row.PAYOUT_ADDRESS, function () { next(); });
          });
          return;
        }
        if (tip - toInt(row.COLLECT_BLOCK) >= RETRY_BLOCKS) {
          msql("UPDATE fc_collect SET status='DETECTED', updated=" + nowMs() + " WHERE fc_coinid=" + q(row.FC_COINID), function () {
            if (toInt(row.ATTEMPTS) === MAX_ATTEMPTS) {
              if (notifyOn) { try { MDS.notify("Future Cash: a collection keeps failing — check this node"); } catch (e) {} }
              logMsg("error", "Collect still failing after " + row.ATTEMPTS + " tries | stake:" + row.FC_COINID + " | to:" + row.PAYOUT_ADDRESS, function () { next(); });
            } else { logMsg("warn", "Collect retry scheduled | stake:" + row.FC_COINID + " | to:" + row.PAYOUT_ADDRESS, function () { next(); }); }
          });
        } else next();
      });
    }, function () { cb(); });
  });
}

/* ----- SWEEP (at-risk collected coins only) ----- */
function detectCollectedForSweep(tip, cb) {
  msql("SELECT coinid FROM fc_sweep", function (sr) {
    var claimed = {}, sweepRows = (sr && sr.rows) || [];
    for (var k = 0; k < sweepRows.length; k++) claimed[String(sweepRows[k].COINID)] = true;
    msql("SELECT * FROM fc_collect WHERE status='COLLECTED'", function (r) {
      var rows = (r && r.rows) || [];
      eachSeries(rows, function (row, idx, next) {
        mcmd("coins relevant:true sendable:true address:" + row.PAYOUT_ADDRESS, function (cr) {
          var arr = (cr && isArr(cr.response)) ? cr.response : [];
          var found = null;
          for (var i = 0; i < arr.length; i++) {
            var c = arr[i];
            if (!c || c.spent === true) continue;
            if (claimed[String(c.coinid)]) continue;
            if (String(c.tokenid) !== String(row.TOKENID)) continue;
            if (String(coinOutAmount(c)) !== String(row.OUT_AMOUNT)) continue;
            var created = parseNum(c.created);
            if (created != null && created < toInt(row.COLLECT_BLOCK)) continue;
            found = c; break;
          }
          if (!found) { next(); return; }
          claimed[String(found.coinid)] = true;
          msql("INSERT INTO fc_sweep (coinid,address,tokenid,amount,status,sweep_block,attempts,updated) VALUES (" +
            q(found.coinid) + "," + q(found.address) + "," + q(found.tokenid) + "," + q(coinOutAmount(found)) + ",'PENDING',0,0," + nowMs() + ")", function () {
            msql("UPDATE fc_collect SET status='SWEEP_QUEUED', updated=" + nowMs() + " WHERE fc_coinid=" + q(row.FC_COINID), function () {
              logMsg("info", "Queued " + coinOutAmount(found) + " " + tokLabel(found.tokenid) + " for sweep to safe | coin:" + found.coinid + " | on:" + found.address, function () { next(); });
            });
          });
        });
      }, function () { cb(); });
    });
  });
}

// Coins stranded on our RETIRED addresses — bare-collected there before we flagged them at-risk, or any
// deposit onto a nulled-key address — that aren't already queued. Queue them for the normal sweep;
// sweepPending signs with the EXPLICIT key from each address's SIGNEDBY script (auto can't, the row key
// is nulled), lifting them to the configured safe. This drains funds off reused (at-risk) addresses continuously.
function detectStrandedForSweep(tip, cb) {
  retiredAddrs(function (cands) {
    if (!cands.length) { cb(); return; }
    msql("SELECT coinid FROM fc_sweep", function (sr) {
      var claimed = {}, srows = (sr && sr.rows) || [];
      for (var k = 0; k < srows.length; k++) claimed[String(srows[k].COINID)] = true;
      eachSeries(cands, function (addr, idx, next) {
        mcmd("coins address:" + addr, function (cr) {
          var coins = (cr && isArr(cr.response)) ? cr.response : [];
          eachSeries(coins, function (c, j, next2) {
            if (!c || !c.coinid || c.spent === true || claimed[String(c.coinid)]) { next2(); return; }
            claimed[String(c.coinid)] = true;
            msql("INSERT INTO fc_sweep (coinid,address,tokenid,amount,status,sweep_block,attempts,updated) VALUES (" +
              q(c.coinid) + "," + q(addr) + "," + q(c.tokenid) + "," + q(coinOutAmount(c)) + ",'PENDING',0,0," + nowMs() + ")", function () {
              logMsg("info", "Stranded " + coinOutAmount(c) + " " + tokLabel(c.tokenid) + " | coin:" + c.coinid + " | on retired:" + addr + " — queued to sweep to safe", function () { next2(); });
            });
          }, function () { next(); });
        });
      }, function () { cb(); });
    });
  });
}

function sweepPending(tip, safe, cb) {
  msql("SELECT * FROM fc_sweep WHERE status='PENDING'", function (r) {
    var rows = (r && r.rows) || [];
    eachSeries(rows, function (row, idx, next) {
      // Sign with the payout address's REAL key (extracted from its SIGNEDBY script), not publickey:auto
      // — auto reads the script-row pubkey, which retire nulls to 0x00, so it can't sign a retired
      // address. The explicit key is still in the keys table and works whether or not it was retired.
      scriptRowFor(row.ADDRESS, function (srow) {
        var pkm = (srow && srow.script) ? /SIGNEDBY\((0x[0-9a-fA-F]+)\)/i.exec(srow.script) : null;
        var signKey = (pkm && pkm[1]) ? pkm[1] : "auto";
        msql("UPDATE fc_sweep SET status='SWEEP_POSTED', sweep_block=" + toInt(tip) + ", attempts=attempts+1, updated=" + nowMs() + " WHERE coinid=" + q(row.COINID), function () {
          var id = txid("SWP");
          buildAndPost(id, [
            "txncreate id:" + id,
            "txninput id:" + id + " coinid:" + row.COINID,
            "txnoutput id:" + id + " address:" + safe + " amount:" + row.AMOUNT + " tokenid:" + row.TOKENID + " storestate:false",
            "txnsign id:" + id + " publickey:" + signKey,
            "txnbasics id:" + id + ";txnpost id:" + id
          ], function (err) {
            if (!err) { markWriteConfirmed(true, function () { logMsg("info", "Sweeping " + row.AMOUNT + " " + tokLabel(row.TOKENID) + " | coin:" + row.COINID + " | from:" + row.ADDRESS + " | to:" + safe, function () { next(); }); }); }
            else {
              if (looksLikeVaultLockError(errMsg(err))) { g_vaultLocked = true; }
              handlePostError(err, "Sweep", "coin:" + row.COINID + " | from:" + row.ADDRESS, function () { next(); });
            }
          });
        });
      });
    }, function () { cb(); });
  });
}

function outputArrivedAtSafe(safe, row, cb) {
  msql("SELECT note FROM fc_sweep", function (nr) {
    if (!nr || nr.status !== true || !isArr(nr.rows)) { cb({ ok: false, coinid: null }); return; }
    var used = {}, nrows = nr.rows;
    for (var k = 0; k < nrows.length; k++) { var nv = nrows[k].NOTE; if (nv != null && nv !== "") used[String(nv)] = true; }
    mcmd("coins address:" + safe + " tokenid:" + row.TOKENID, function (r) {
      if (!r || r.status !== true || !isArr(r.response)) { cb({ ok: false, coinid: null }); return; }
      var arr = r.response;
      for (var i = 0; i < arr.length; i++) {
        var c = arr[i];
        // In samenode mode the safe is OUR OWN address, so a matching coin that's since been SPENT still
        // proves it arrived (we then spent it) — don't treat that as a loss. In external mode only an
        // unspent output counts (a spent one at an external addr isn't ours to interpret).
        if (!c || !c.coinid || used[String(c.coinid)]) continue;
        if (c.spent === true && g_safeMode !== "samenode") continue;
        if (String(c.tokenid) !== String(row.TOKENID)) continue;
        if (String(coinOutAmount(c)) !== String(row.AMOUNT)) continue;
        var created = parseNum(c.created);
        if (created != null && created < toInt(row.SWEEP_BLOCK)) continue;
        cb({ ok: true, coinid: c.coinid }); return;
      }
      cb({ ok: true, coinid: null });
    });
  });
}

function reconcileSweeps(tip, safe, cb) {
  // Only SAMENODE safes can be verified. setSafeAddress REQUIRES an external safe to be an address
  // this node does not track, so `coins address:<external safe>` is always empty — which the check
  // below would read as "verified absent" and alarm the user that a perfectly good sweep was stolen.
  // No verification ability is not the same as evidence of loss.
  var canVerify = safe && validMx(safe) && g_safeMode === "samenode";
  msql("SELECT * FROM fc_sweep WHERE status='SWEEP_POSTED'", function (r) {
    var rows = (r && r.rows) || [];
    eachSeries(rows, function (row, idx, next) {
      coinIsUnspent(row.COINID, function (unspent) {
        if (!unspent) {
          function markSwept(outCoinid) {
            var noteSql = outCoinid ? (", note=" + q(outCoinid)) : "";
            msql("UPDATE fc_sweep SET status='SWEPT'" + noteSql + ", updated=" + nowMs() + " WHERE coinid=" + q(row.COINID), function () {
              cfgSet("last_action", "Secured " + row.AMOUNT + " " + tokLabel(row.TOKENID) + " to safe @block " + tip, function () {
                if (notifyOn) { try { MDS.notify("Future Cash: secured " + row.AMOUNT + " " + tokLabel(row.TOKENID) + " to your safe address"); } catch (e) {} }
                logMsg("info", "Secured " + row.AMOUNT + " " + tokLabel(row.TOKENID) + " | coin:" + row.COINID + " | to:" + safe, function () { next(); });
              });
            });
          }
          if (!canVerify) { markSwept(null); return; }
          outputArrivedAtSafe(safe, row, function (res) {
            if (res.coinid) { markSwept(res.coinid); return; }
            if (res.ok && (tip - toInt(row.SWEEP_BLOCK) >= VERIFY_GRACE)) {
              msql("UPDATE fc_sweep SET status='TAKEN', updated=" + nowMs() + " WHERE coinid=" + q(row.COINID), function () {
                if (notifyOn) { try { MDS.notify("Future Cash: ⚠️ a collected stake (" + row.AMOUNT + " " + tokLabel(row.TOKENID) + ") was spent but did NOT reach your safe address. Your old key may be compromised — check now."); } catch (e) {} }
                logMsg("error", "⚠️ ALERT: a collected stake was spent but NOT seen at your safe — check for key-reuse loss | coin:" + row.COINID + " | from:" + row.ADDRESS, function () { next(); });
              });
              return;
            }
            if (!res.ok && (tip - toInt(row.SWEEP_BLOCK) >= VERIFY_MAX)) {
              msql("UPDATE fc_sweep SET status='SWEPT', note='unverified', updated=" + nowMs() + " WHERE coinid=" + q(row.COINID), function () {
                if (notifyOn) { try { MDS.notify("Future Cash: a stake was spent but the node couldn't confirm it reached your safe address — please verify it arrived."); } catch (e) {} }
                logMsg("warn", "Sweep spent but UNVERIFIED — please check it arrived | coin:" + row.COINID + " | from:" + row.ADDRESS, function () { next(); });
              });
              return;
            }
            next();
          });
          return;
        }
        if (tip - toInt(row.SWEEP_BLOCK) >= RETRY_BLOCKS) {
          msql("UPDATE fc_sweep SET status='PENDING', updated=" + nowMs() + " WHERE coinid=" + q(row.COINID), function () {
            if (toInt(row.ATTEMPTS) === MAX_ATTEMPTS) {
              if (notifyOn) { try { MDS.notify("Future Cash: a sweep keeps failing — funds still on an exposed address. Is your vault unlocked?"); } catch (e) {} }
              logMsg("error", "Sweep still failing after " + row.ATTEMPTS + " tries | coin:" + row.COINID + " | from:" + row.ADDRESS, function () { next(); });
            } else { logMsg("warn", "Sweep retry scheduled | coin:" + row.COINID + " | from:" + row.ADDRESS, function () { next(); }); }
          });
        } else next();
      });
    }, function () { cb(); });
  });
}

function isSafeUsable(safe, forbiddenObj) {
  if (!validMx(safe)) return false;
  // same-node mode: the safe IS one of our own (fresh, clean) addresses — allow it, but never a
  // reused/at-risk one. external mode: reject anything this node tracks (must be a different wallet).
  if (g_safeMode === "samenode") return !isAtRisk(safe);
  if (forbiddenObj[safe] === true) return false;
  return true;
}

// ONE-TIME purge of work rows that only ever got in because of the pre-3.1.21 ownership check
// (see hasOwnKey). Those rows point at stakes that were never this user's — on a node that ran
// 3.1.20 with auto-collect on, the guardian was posting collects for them. Runs once per install.
function purgeForeignRows(cb) {
  cfgGet("purge_foreign_done", null, function (done) {
    if (done === "1") { cb(); return; }
    getAddressSets(function (sets) {
      msql("SELECT fc_coinid,payout_address FROM fc_collect", function (r) {
        var rows = (r && r.rows) || [], drop = [];
        for (var i = 0; i < rows.length; i++) {
          if (!ownsAddress(sets.ownDefault, rows[i].PAYOUT_ADDRESS)) drop.push(rows[i].FC_COINID);
        }
        eachSeries(drop, function (id, idx, next) {
          msql("DELETE FROM fc_collect WHERE fc_coinid=" + q(id), function () { next(); });
        }, function () {
          cfgSet("purge_foreign_done", "1", function () {
            if (!drop.length) { cb(); return; }
            logMsg("warn", "Removed " + drop.length + " stake(s) that were never yours — an older version mistook contract addresses for your own and could collect other people's stakes", function () { cb(); });
          });
        });
      });
    });
  });
}

/* ----- Reconcile pass ----- */
function reconcile(tip) {
  if (g_busy && (nowMs() - g_busyAt) < 120000) return;
  g_busy = true; g_busyAt = nowMs(); g_vaultLocked = false;
  function finish() { writeStatus(tip, function () { g_busy = false; }); }

  cfgSet("last_tip", "" + tip, function () {
    ensureTables(function () {
      g_tablesReady = true;
      maybeHandleReset(function () {
        purgeForeignRows(function () {
        loadAtRisk(function () {
          cfgGet("notify", "1", function (nv) {
            notifyOn = (nv === "1");
            cfgGet("auto_collect_safe", "0", function (acs) {
              var autoCollectSafe = (acs === "1");
              cfgGet("enabled", "0", function (ev) {
                var rescueEnabled = (ev === "1");
                cfgGet("safe_address", null, function (safe) {
                  getFcScanAddresses(function (fcAddrs) {
                    getAddressSets(function (sets) {
                      detectFutureCash(tip, sets.ownDefault, fcAddrs, function () {
                        // A SAFE bare-collect requires a fresh, successful audit (else we can't trust the
                        // payout is safe). Rescue (collect+sweep) requires a usable safe address AND an
                        // unlocked vault, checked BEFORE collecting so an at-risk/unknown coin is only
                        // pulled onto its exposed address when a sweep can immediately follow.
                        cfgGet("audit_ok", "0", function (aok) {
                          cfgGet("audit_at", "0", function (aat) {
                            var auditFresh = (aok === "1") && ((nowMs() - toInt(aat)) < AUDIT_FRESH_MS);
                            var safeUsable = safe && isSafeUsable(safe, sets.allTracked);
                            function proceed(canSweep) {
                              collectMatured(tip, autoCollectSafe, rescueEnabled, auditFresh, canSweep, sets.ownDefault, function () {
                                reconcileCollects(tip, function () {
                                  detectCollectedForSweep(tip, function () {
                                    function afterStranded() {
                                      function afterSweep() { reconcileSweeps(tip, safe, function () { finish(); }); }
                                      if (canSweep) sweepPending(tip, safe, afterSweep);
                                      else afterSweep();
                                    }
                                    // Only hunt stranded coins when we can actually sweep them (usable safe + unlocked).
                                    if (canSweep) detectStrandedForSweep(tip, afterStranded);
                                    else afterStranded();
                                  });
                                });
                              });
                            }
                            if (rescueEnabled && safeUsable) {
                              vaultLocked(function (locked) {
                                g_vaultLocked = locked;
                                if (locked && !g_lockNotified) { g_lockNotified = true; logMsg("warn", "Vault locked — rescue paused until you unlock it", function () { proceed(false); }); }
                                else { if (!locked) g_lockNotified = false; proceed(!locked); }
                              });
                            } else { proceed(false); }
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
        });
      });
    });
  });
}

/* ----- UI-facing API ----- */
function setSafeAddress(addr, cb) {
  addr = String(addr || "").trim();
  if (!validMx(addr)) { cb({ ok: false, error: "Not a valid Mx address (must start with Mx)." }); return; }
  var localErr = "That address belongs to THIS node. Use an EXTERNAL wallet (a different node/seed) with fresh keys.";
  getAddressSets(function (sets) {
    if (sets.allTracked[addr] === true) { cb({ ok: false, error: localErr }); return; }
    addressIsLocal(addr, function (local) {
      if (local) { cb({ ok: false, error: localErr }); return; }
      cfgSet("safe_mode", "external", function () {
        cfgSet("safe_address", addr, function () {
          cfgGet("safe_address", null, function (rb) {
            if (rb !== addr) { cb({ ok: false, error: "Write did NOT persist (keypair storage is failing on this node)." }); return; }
            logMsg("info", "Safe address set (external) | address:" + addr, function () { cb({ ok: true }); });
          });
        });
      });
    });
  });
}

// A single fresh CLEAN address on THIS node where rescued/swept funds collect. Minted once
// (newaddress = unused key, defaultaddress=0 so change never routes to it) and reused thereafter.
// cb({ok:true, mx, hex}) | {ok:false, error}.
function getOrMintCleanAddr(cb) {
  cfgGet("clean_addr", null, function (raw) {
    var blob = null; try { blob = raw ? JSON.parse(raw) : null; } catch (e) { blob = null; }
    if (blob && blob.mx && blob.hex && validMx(blob.mx) && /^0x/i.test(blob.hex)) { cb({ ok: true, mx: blob.mx, hex: blob.hex }); return; }
    // Minting CREATES a key pair, which a locked vault (private keys wiped or password-locked)
    // cannot do — `newaddress` just fails. Check first so the user gets the real reason and a fix
    // instead of a dead-end "couldn't mint". Only paid when we actually need to mint.
    vaultLocked(function (locked) {
      if (locked) { cb({ ok: false, error: "Your node's keys are locked, so it can't make a new address. Unlock your node (Vault), then try again." }); return; }
      mcmd("newaddress", function (r) {
        if (r && r.pending) { cb({ ok: false, error: "Stuck as a pending request — Future Cash doesn't work in READ mode. Switch it to WRITE in MiniHub, then retry." }); return; }
        var resp = r && r.response;
        var nmx = resp && resp.miniaddress, nhex = resp && resp.address;
        // Surface the node's own error — swallowing it made a locked vault, a permissions hold and a
        // malformed response all look identical, which is why this took a terminal session to find.
        if (!nmx || !validMx(nmx) || !nhex || !/^0x/i.test(nhex)) { cb({ ok: false, error: "Couldn't make a fresh address on this node." + (r && r.error ? " (" + r.error + ")" : "") }); return; }
        // Store mx+hex as ONE atomic blob so a concurrent mint can't pair addr A's hex with addr B's mx.
        cfgSet("clean_addr", JSON.stringify({ mx: nmx, hex: nhex }), function () {
          logMsg("info", "Clean same-node destination set | address:" + nmx, function () { cb({ ok: true, mx: nmx, hex: nhex }); });
        });
      });
    });
  });
}

// Destination for a MANUAL sweep (Recover): honour the configured EXTERNAL safe when rescue is on +
// external mode + a valid safe is set — so Recover lands funds in the same place the automatic rescue
// does (e.g. the user's external wallet). Otherwise fall back to a fresh same-node clean address (the
// local-unstick default, and the samenode-mode behaviour). txnoutput accepts an Mx directly, as
// sweepPending already does with `safe`. cb({ok:true, mx, hex}) | {ok:false, error}.
function getSweepDest(cb) {
  cfgGet("enabled", "0", function (ev) {
    cfgGet("safe_mode", "external", function (sm) {
      cfgGet("safe_address", "", function (sa) {
        if (ev === "1" && sm === "external" && validMx(sa)) { cb({ ok: true, mx: sa, hex: sa }); return; }
        getOrMintCleanAddr(cb);
      });
    });
  });
}

// Point the at-risk rescue at a fresh clean address on THIS node (for single-device users).
function setSafeSameNode(cb) {
  getOrMintCleanAddr(function (r) {
    if (!r.ok) { cb(r); return; }
    cfgSet("safe_mode", "samenode", function () {
      cfgSet("safe_address", r.mx, function () {
        cfgGet("safe_address", null, function (rb) {
          if (rb !== r.mx) { cb({ ok: false, error: "Write did NOT persist (keypair storage failing)." }); return; }
          logMsg("info", "Safe destination = a fresh same-node address | address:" + r.mx, function () { cb({ ok: true, address: r.mx }); });
        });
      });
    });
  });
}

// Sweep ALL coins off a reused (at-risk) address to the fresh clean same-node destination. Signs
// with the reused key once per coin to evacuate — acceptable because the address has already been reused
// and speed is the protection. Naturally idempotent (spent coins don't reappear). User-initiated
// (needs WRITE). cb({ok:true, swept, dest} | {ok:false, error}).
function sweepAddressToClean(reusedAddr, cb) {
  if (!/^0x[0-9a-fA-F]+$/.test(reusedAddr) && !validMx(reusedAddr)) { cb({ ok: false, error: "Invalid address." }); return; }
  scriptRowFor(reusedAddr, function (s) {
    if (!s) { cb({ ok: false, error: "Address not found on this node." }); return; }
    var mine = (s.publickey && s.publickey !== "0x00") || (s.script && /SIGNEDBY/i.test(s.script));
    if (!mine) { cb({ ok: false, error: "That isn't one of your signable addresses." }); return; }
    var fromHex = s.address;
    // Sign with the address's REAL public key (from its SIGNEDBY script), NOT publickey:auto — auto
    // (and `send`) read the script-row pubkey, which retire nulls to 0x00, so they can't sign a
    // retired address. The explicit key is looked up in the keys table (still present) and works.
    var pkm = /SIGNEDBY\((0x[0-9a-fA-F]+)\)/i.exec(s.script || "");
    var signKey = (pkm && pkm[1]) ? pkm[1] : "auto";
    getSweepDest(function (dest) {
      if (!dest.ok) { cb(dest); return; }
      if (canonAddr(dest.hex) === canonAddr(fromHex)) { cb({ ok: false, error: "Destination equals the source address." }); return; }
      mcmd("coins address:" + fromHex, function (cr) {
        if (!cr || cr.status !== true || !isArr(cr.response)) { cb({ ok: false, error: "Couldn't read this address's coins — try again." }); return; }
        var coins = [], resp = cr.response;
        for (var i = 0; i < resp.length; i++) { var c = resp[i]; if (c && c.coinid && c.spent !== true) coins.push(c); }
        if (!coins.length) { cb({ ok: true, swept: 0, dest: dest.mx }); return; }
        var swept = 0, failed = 0, lastErr = null, bailed = false;
        eachSeries(coins, function (c, idx, next) {
          if (bailed) { next(); return; }
          var id = txid("ADS");
          buildAndPost(id, [
            "txncreate id:" + id,
            "txninput id:" + id + " coinid:" + c.coinid,
            "txnoutput id:" + id + " address:" + dest.hex + " amount:" + coinOutAmount(c) + " tokenid:" + c.tokenid + " storestate:false",
            "txnsign id:" + id + " publickey:" + signKey,
            "txnbasics id:" + id + ";txnpost id:" + id
          ], function (err) {
            if (!err) {
              swept++;
              markWriteConfirmed(true, function () {
                logMsg("info", "Swept " + coinOutAmount(c) + " " + tokLabel(c.tokenid) + " | coin:" + c.coinid + " | from:" + fromHex + " | to safe:" + dest.mx, function () { next(); });
              });
              return;
            }
            lastErr = errMsg(err); failed++;
            if (/pending|READ mode/i.test(lastErr)) { bailed = true; cb({ ok: false, error: "Stuck as a pending request — Future Cash doesn't work in READ mode. Switch it to WRITE in MiniHub, then retry." }); return; }
            logMsg("warn", "Couldn't sweep " + coinOutAmount(c) + " " + tokLabel(c.tokenid) + " | coin:" + c.coinid + " | on:" + fromHex + " — " + lastErr, function () { next(); });
          });
        }, function () {
          if (bailed) return;   // already reported the READ-mode bail
          logMsg("info", "Swept " + swept + " coin(s) off a reused address" + (failed ? " (" + failed + " failed)" : "") + " | from:" + fromHex + " | to:" + dest.mx, function () {
            cb({ ok: swept > 0, swept: swept, failed: failed, dest: dest.mx, error: (swept === 0 ? (lastErr || "Nothing swept.") : null) });
          });
        });
      });
    });
  });
}

function storageSelfTest(cb) {
  var token = "t" + nowMs();
  cfgSet("kp_selftest", token, function () { cfgGet("kp_selftest", null, function (rb) { cb(rb === token); }); });
}
function setRescueEnabled(on, cb) {
  if (on) {
    cfgGet("safe_address", null, function (safe) {
      if (!safe) { cb({ ok: false, error: "Set a safe address before enabling rescue." }); return; }
      cfgSet("enabled", "1", function () { logMsg("info", "At-risk rescue ENABLED", function () { cb({ ok: true }); }); });
    });
  } else { cfgSet("enabled", "0", function () { logMsg("info", "At-risk rescue DISABLED", function () { cb({ ok: true }); }); }); }
}
function setAutoCollectSafe(on, cb) { cfgSet("auto_collect_safe", on ? "1" : "0", function () { logMsg("info", "Auto-collect safe stakes " + (on ? "ON" : "OFF"), function () { if (cb) cb({ ok: true }); }); }); }
function setNotify(on, cb) { cfgSet("notify", on ? "1" : "0", function () { if (cb) cb({ ok: true }); }); }

// Manually bare-collect ONE matured stake now (page-invoked). Same WOTS-safety gates as the
// engine: refuses at-risk payouts (the rescue path owns those) and refuses without a fresh full
// audit. Posts directly and leaves fc_collect alone — the next reconcile sees the coin spent and
// marks its row COLLECTED. cb({ok, amount, tokenid}|{ok:false, error}).
function collectStakeNow(coinid, cb) {
  if (!coinid) { cb({ ok: false, error: "No stake specified." }); return; }
  mcmd("block", function (b) {
    var tip = (b && b.response && parseInt(b.response.block, 10)) || 0;
    mcmd("coins coinid:" + coinid, function (r) {
      var arr = (r && isArr(r.response)) ? r.response : [];
      var coin = null;
      for (var i = 0; i < arr.length; i++) { if (arr[i] && arr[i].coinid === coinid && arr[i].spent !== true) { coin = arr[i]; break; } }
      if (!coin) { cb({ ok: false, error: "Stake not found — it may already be collected." }); return; }
      if (!looksLikeFutureCash(coin)) { cb({ ok: false, error: "Not a FutureCash stake." }); return; }
      var s1 = parseNum(getState(coin, 1)), s4 = parseNum(getState(coin, 4)), created = parseNum(coin.created);
      var matured = (s1 != null && tip >= s1) || (s4 != null && created != null && (tip - created) >= s4);
      if (!matured) { cb({ ok: false, error: "Not matured yet — unlocks at block " + s1 + " (now " + tip + ")." }); return; }
      var payout = getState(coin, 2), outAmt = coinOutAmount(coin), tok = coin.tokenid;
      // OWNERSHIP FIRST. This takes a coinid straight from the page, so it must make the same check
      // the engine makes — a stake that doesn't pay out to us is not ours to collect, however it got
      // in front of the user.
      getAddressSets(function (sets) {
        if (!ownsAddress(sets.ownDefault, payout)) { cb({ ok: false, error: "That stake doesn't pay out to this node — it isn't yours to collect." }); return; }
        loadAtRisk(function () {
        if (isAtRisk(payout)) { cb({ ok: false, error: "This stake pays out to an at-risk address — the Guardian rescues it with collect + sweep instead. Set up rescue on the Guardian tab." }); return; }
        cfgGet("audit_ok", "0", function (okv) {
          cfgGet("audit_at", "0", function (atv) {
            var fresh = (okv === "1") && ((nowMs() - toInt(atv)) < AUDIT_FRESH_MS);
            if (!fresh) { cb({ ok: false, error: "Run a key audit first (Guardian tab → Re-audit), then collect." }); return; }
            var id = txid("COL");
            buildAndPost(id, [
              "txncreate id:" + id,
              "txninput id:" + id + " coinid:" + coin.coinid,
              "txnoutput id:" + id + " address:" + payout + " amount:" + outAmt + " tokenid:" + tok + " storestate:false",
              "txnbasics id:" + id + ";txnpost id:" + id
            ], function (err) {
              if (err) {
                var msg = errMsg(err);
                if (/pending|READ mode/i.test(msg)) {
                  markWriteConfirmed(false, function () { cb({ ok: false, error: "Stuck as a pending request — Future Cash doesn't work in READ mode. Switch it to WRITE in MiniHub, then retry." }); });
                  return;
                }
                cb({ ok: false, error: msg });
                return;
              }
              markWriteConfirmed(true, function () {
                logMsg("info", "Manual collect posted: " + outAmt + " " + tokLabel(tok) + " | stake:" + coinid + " | to:" + payout, function () {
                  cb({ ok: true, amount: outAmt, tokenid: tok });
                });
              });
            });
          });
        });
        });
      });
    });
  });
}

// Write the at-risk address set (called by the page after it runs the KeyUses audit).
function setAtRiskAddrs(addrArray, cb) {
  var arr = isArr(addrArray) ? addrArray : [];
  // NOTE: audit_at is deliberately NOT stamped here. The caller writes audit_ok first and audit_at
  // LAST, so freshness can never outrun the ok/partial verdict. Stamping it here reopened a window
  // where audit_at was fresh while audit_ok still held the PREVIOUS run's value — a partial audit
  // then read as fresh-and-complete and could license a bare-collect onto a reused address.
  cfgSet("atrisk_addrs", JSON.stringify(arr), function () {
    // Log ONLY when the at-risk count changes — the page re-audits every ~90s, so logging every run
    // floods the Activity pane and buries the real actions.
    cfgGet("audit_logged_n", "-1", function (prev) {
      if (String(arr.length) === String(prev)) { if (cb) cb({ ok: true }); return; }
      cfgSet("audit_logged_n", "" + arr.length, function () {
        logMsg("info", "Audit: " + arr.length + " at-risk address(es)", function () { if (cb) cb({ ok: true }); });
      });
    });
  });
}

// Create (lock) a FutureCash payment: lock `amount` of `tokenid` until `blocks` from now, payable
// to `payoutHex` (a 0x address — the caller resolves it, e.g. from getaddress for self, or
// checkaddress for a recipient Mx). cb({ok}|{ok:false,error}).
function createFutureCash(amount, tokenid, blocks, payoutHex, maturityMs, cb) {
  var amt = Number(amount), blk = parseInt(blocks, 10);
  if (!(amt > 0)) { cb({ ok: false, error: "Enter a positive amount." }); return; }
  if (!(blk > 0)) { cb({ ok: false, error: "Pick a maturity time in the future." }); return; }
  if (!/^0x[0-9a-fA-F]{2,}$/.test(String(payoutHex || ""))) { cb({ ok: false, error: "Payout address unresolved." }); return; }
  var tok = tokenid || "0x00";
  var matMs = (maturityMs && Number(maturityMs) > 0) ? Math.floor(Number(maturityMs)) : (nowMs() + blk * 50000);
  fcScriptAddress(function (contract) {
    if (!contract) { cb({ ok: false, error: "Could not register the FutureCash contract." }); return; }
    mcmd("block", function (b) {
      var tip = b && b.response && parseInt(b.response.block, 10);
      if (!tip) { cb({ ok: false, error: "Could not read the chain tip." }); return; }
      var matBlock = tip + blk;
      // port1=maturity block (enforced), port2=payout, port3=maturity timestamp (display), port4=coinage.
      var state = '{"0":"0xFF","1":"' + matBlock + '","2":"' + payoutHex + '","3":"' + matMs + '","4":"' + blk + '"}';
      var cmd = "send amount:" + amount + " address:" + contract + (isMinima(tok) ? "" : " tokenid:" + tok) + " state:" + state;
      mcmd(cmd, function (res) {
        var arr = isArr(res) ? res : [res], r = arr[0];
        if (r && r.pending) { cb({ ok: false, error: "Future Cash doesn't work in READ mode — switch it to WRITE in MiniHub, then lock again." }); return; }
        if (r && r.status) { logMsg("info", "Locked " + amount + " " + tokLabel(tok) + " · matures block " + matBlock + " | to:" + payoutHex, function () { cb({ ok: true, matBlock: matBlock, payout: payoutHex, maturityMs: matMs }); }); }
        else { cb({ ok: false, error: (r && r.error) || "Send failed." }); }
      });
    });
  });
}

/* ----- Retire reused addresses -----
 * Minima routes ALL automatic change through Wallet.getDefaultAddress() = a random pick from the
 * node's default addresses (defaultaddress<>0). There is no "avoid" flag and `send` has no change:
 * param, so change keeps landing on reused (at-risk) addresses. We can't heal a reused address in
 * place (the leaf is already exposed), but we CAN stop the node ever funding it again: `newscript`
 * with the address's own script removes the default row and re-adds it as a NON-default, watch-only
 * script (defaultaddress=0, track=1). getDefaultAddress (DB-backed) then never selects it, while the
 * coin stays visible (and the private key stays in the keys table, so a straggler is still
 * sweepable). Moves NO funds. NOTE: survives restarts (DB) but NOT a full reseed-from-seed
 * (derivation is deterministic — the defaults regenerate), so re-run this after any reinstall. */

// Read one scripts row for an address (response is a single object when queried by address).
function scriptRowFor(addr, cb) {
  mcmd("scripts address:" + addr, function (r) {
    var resp = r && r.response;
    var s = (resp && !isArr(resp)) ? resp : (isArr(resp) && resp.length ? resp[0] : null);
    cb((s && s.script) ? s : null);
  });
}

// List the node's OWN reused addresses (from the audit's atrisk_addrs), deduped, each with whether
// it's still an active default (needs retiring) and its current unspent balance. cb([{addr,mx,isDefault,balance,script}]).
function listReusedDefaults(cb) {
  cfgGet("atrisk_addrs", "[]", function (raw) {
    var arr = []; try { arr = JSON.parse(raw); } catch (e) { arr = []; }
    if (!isArr(arr)) arr = [];
    var out = [], seen = {};
    eachSeries(arr, function (a, idx, next) {
      scriptRowFor(a, function (s) {
        if (!s || !s.address) { next(); return; }
        var key = String(s.address).toLowerCase();
        if (seen[key]) { next(); return; }         // dedupe hex+Mx forms of the same address
        seen[key] = true;
        // Only our own addresses (has a publickey / SIGNEDBY script). Others (someone else's reused
        // payout we happen to track) are not ours to retire.
        var mine = s.publickey && s.publickey !== "0x00" || (s.script && /SIGNEDBY/i.test(s.script));
        if (!mine) { next(); return; }
        mcmd("coins address:" + s.address, function (cr) {
          var coins = (cr && isArr(cr.response)) ? cr.response : [];
          var bal = 0;
          for (var i = 0; i < coins.length; i++) { var c = coins[i]; if (c && c.spent !== true && isMinima(c.tokenid)) bal += Number(c.amount) || 0; }
          var anyCoin = 0; for (var j = 0; j < coins.length; j++) { if (coins[j] && coins[j].spent !== true) anyCoin++; }
          out.push({ addr: s.address, mx: s.miniaddress || "", isDefault: (s.default === true), balance: bal, coins: anyCoin, script: s.script });
          next();
        });
      });
    }, function () { cb(out); });
  });
}

// Count the node's live default change addresses (defaultaddress<>0). cb(n) or cb(-1) if unknown.
function countDefaults(cb) {
  mcmd("scripts", function (r) {
    if (!r || r.status !== true || !isArr(r.response)) { cb(-1); return; }
    var n = 0, arr = r.response;
    for (var i = 0; i < arr.length; i++) { if (arr[i] && arr[i].default === true) n++; }
    cb(n);
  });
}

// Does any FutureCash/Maximize stake (pending or matured, unspent) pay out to this address? If so it
// must NOT be retired — collecting it would deposit funds here, and a retired address can't be swept.
function addressHasStakes(payoutAddr, cb) {
  // Resolve to the hex form first: stake payouts (state port 2) are stored hex, and canonAddr can't
  // bridge hex<->Mx, so an Mx-form caller would otherwise false-negative this fund-safety gate.
  scriptRowFor(payoutAddr, function (srow) {
    var target = canonAddr((srow && srow.address) ? srow.address : payoutAddr);
    var targetRaw = canonAddr(payoutAddr), found = false;
    function scan(arr) {
      if (!isArr(arr)) return;
      for (var i = 0; i < arr.length; i++) {
        var c = arr[i];
        if (!c || c.spent === true || !looksLikeFutureCash(c)) continue;
        var p = getState(c, 2);
        if (p) { var cp = canonAddr(p); if (cp === target || cp === targetRaw) { found = true; return; } }
      }
    }
    getFcScanAddresses(function (fcAddrs) {
      mcmd("coins relevant:true", function (r1) {
        scan(r1 && r1.response);
        if (found) { cb(true); return; }
        eachSeries(fcAddrs, function (sa, idx, next) {
          if (found) { next(); return; }
          mcmd("coins address:" + sa, function (r2) { scan(r2 && r2.response); next(); });
        }, function () { cb(found); });
      });
    });
  });
}

// The node's own RETIRED simple addresses: script-row publickey nulled to 0x00, script EXACTLY
// "RETURN SIGNEDBY(0x<key>)" (a pure single-sig — NOT a compound contract) of one of THIS node's keys.
// Excludes old/foreign CONTRACTS (minimaSwap/old-FutureCash, compound scripts) and others' watch scripts.
// Retire leaves the key in the keys table, so these are still sweepable via the EXPLICIT key. cb([addrHex,...]).
function retiredAddrs(cb) {
  mcmd("keys action:list", function (kr) {
    var ourKeys = {}, karr = (kr && kr.response && isArr(kr.response.keys)) ? kr.response.keys : [];
    for (var k = 0; k < karr.length; k++) { if (karr[k] && karr[k].publickey) ourKeys[String(karr[k].publickey).toLowerCase()] = true; }
    mcmd("scripts", function (r) {
      var arr = (r && isArr(r.response)) ? r.response : [], out = [];
      for (var i = 0; i < arr.length; i++) {
        var s = arr[i];
        if (!s || s.default === true || s.publickey !== "0x00" || !s.address || !s.script) continue;
        var m = /^RETURN\s+SIGNEDBY\((0x[0-9a-fA-F]+)\)$/i.exec(cleanScript(s.script));
        if (!m || !ourKeys[String(m[1]).toLowerCase()]) continue;   // not a pure single-sig of OUR key -> skip
        out.push(s.address);
      }
      cb(out);
    });
  });
}

// Retired addresses that STILL hold coins (stuck without the explicit key). cb([{addr, coins}]).
function listRetiredWithCoins(cb) {
  retiredAddrs(function (cands) {
    var out = [];
    eachSeries(cands, function (a, idx, next) {
      mcmd("coins address:" + a, function (cr) {
        var coins = (cr && isArr(cr.response)) ? cr.response : [], n = 0;
        for (var j = 0; j < coins.length; j++) { if (coins[j] && coins[j].spent !== true) n++; }
        if (n > 0) out.push({ addr: a, coins: n });
        next();
      });
    }, function () { cb(out); });
  });
}

// Sweep every stuck coin off retired addresses to the clean same-node address (explicit-key sign, via
// sweepAddressToClean). Undoes the retire damage without a reseed. cb({ok, recovered, failed, addresses}).
function recoverRetiredCoins(cb) {
  listRetiredWithCoins(function (list) {
    if (!list.length) { cb({ ok: true, recovered: 0, addresses: 0 }); return; }
    var i = 0, recovered = 0, failed = 0, addrs = 0;
    (function nextOne() {
      if (i >= list.length) { cb({ ok: true, recovered: recovered, failed: failed, addresses: addrs }); return; }
      var a = list[i]; i++;
      sweepAddressToClean(a.addr, function (r) {
        if (r && r.ok) { recovered += (r.swept || 0); addrs++; }
        else { failed++; if (r && r.error && /READ mode|Pending/i.test(r.error)) { cb({ ok: false, error: r.error }); return; } }
        nextOne();
      });
    })();
  });
}

// Retire ONE reused default address: confirm it's an active default, refuse if any stake still pays to
// it, refuse while it still holds coins (sweep first), refuse if it would starve the change pool, flip
// it to watch-only non-default via newscript, then verify against the node. cb({ok}|{ok:false,error}).
function retireAddress(addr, cb) {
  // Gate: never retire an address that FutureCash/Maximize stakes still pay out to — those payouts WILL
  // land here when they mature, and a retired address can't be swept. Keep it live + watched instead.
  addressHasStakes(addr, function (hasStakes) {
    if (hasStakes) { cb({ ok: false, error: "Stakes still pay out to this address — they'd land here when they mature and get stuck on the nulled key. Leave it live; the guardian keeps sweeping. Not retiring." }); return; }
    scriptRowFor(addr, function (s) {
    if (!s) { cb({ ok: false, error: "Address not found on this node." }); return; }
    if (s.default !== true) { cb({ ok: false, error: "Not an active default change address (already retired, or not one of your defaults)." }); return; }
    var script = s.script;
    if (!/SIGNEDBY/i.test(script) || /"/.test(script)) { cb({ ok: false, error: "Unexpected script for a default address — not retiring." }); return; }
    var addrHex = s.address;
    mcmd("coins address:" + addrHex, function (cr) {
      // Fail SAFE: if the coins query didn't return cleanly, do NOT retire — a still-funded address
      // must be swept first, and a bad/empty response must never be read as "empty".
      if (!cr || cr.status !== true || !isArr(cr.response)) { cb({ ok: false, error: "Couldn't check this address's coins right now — try again in a moment." }); return; }
      var coins = cr.response, unspent = 0;
      for (var i = 0; i < coins.length; i++) { if (coins[i] && coins[i].spent !== true) unspent++; }
      if (unspent > 0) { cb({ ok: false, error: "This address still holds " + unspent + " coin(s). Sweep them to safety first (they're on an exposed key), then retire it." }); return; }
      // Pool-floor guard: never drop the change pool to where getDefaultAddress() has nothing to pick.
      countDefaults(function (nDef) {
        if (nDef < 0) { cb({ ok: false, error: "Couldn't check your change-address pool — try again." }); return; }
        if (nDef <= MIN_DEFAULTS_KEEP) { cb({ ok: false, error: "Keep at least " + MIN_DEFAULTS_KEEP + " change addresses. Restart your node to generate fresh clean ones, then retire more." }); return; }
        // Flip to watch-only non-default. newscript removes the existing (default) row then re-adds
        // the same script with defaultaddress=0, track=true.
        mcmd('newscript trackall:true script:"' + script + '"', function (nr) {
          if (nr && nr.pending) { cb({ ok: false, error: "Stuck as a pending request — Future Cash doesn't work in READ mode. Switch it to WRITE in MiniHub, then retry." }); return; }
          if (!nr || !nr.status) { cb({ ok: false, error: (nr && nr.error) || "Retire command failed." }); return; }
          scriptRowFor(addrHex, function (v) {
            if (v && v.default === true) { cb({ ok: false, error: "Retire didn't take effect — the address is still a default." }); return; }
            logMsg("info", "Retired a reused default address — off the change rotation, kept watch-only | address:" + addrHex, function () { cb({ ok: true }); });
          });
        });
      });
    });
  });
  });
}

function clearAllState(cb) {
  var token = "" + nowMs();
  var keys = ["enabled", "auto_collect_safe", "last_tip", "last_action", "write_confirmed", "fc_status", "fc_log", "script_address", "reset_done"];
  var i = 0;
  function nextKey() {
    if (i >= keys.length) {
      g_vaultLocked = false; g_lockNotified = false; g_fcCoins = {};
      cfgSet("reset_request", token, function () { if (cb) cb({ ok: true }); });
      return;
    }
    var k = keys[i]; i++;
    cfgSet(k, "", function () { nextKey(); });
  }
  nextKey();
}

function maybeHandleReset(cb) {
  cfgGet("reset_request", null, function (req) {
    if (!req) { cb(); return; }
    cfgGet("reset_done", null, function (done) {
      if (req === done) { cb(); return; }
      msql("DELETE FROM fc_sweep WHERE status='SWEPT' OR status='TAKEN'", function () {
        msql("DELETE FROM fc_collect WHERE status='DETECTED' OR status='SWEEP_QUEUED' OR status='COLLECTED_SAFE'", function () {
          g_vaultLocked = false; g_lockNotified = false; g_fcCoins = {};
          cfgSet("reset_done", req, function () { logMsg("info", "History reset — in-flight rescues kept", function () { cb(); }); });
        });
      });
    });
  });
}

function countByStatus(table, cb) {
  msql("SELECT status, COUNT(*) AS C FROM " + table + " GROUP BY status", function (r) {
    var o = {}, rows = (r && r.rows) || [];
    for (var i = 0; i < rows.length; i++) o[rows[i].STATUS] = toInt(rows[i].C);
    cb(o);
  });
}

function getSnapshot(cb) {
  var snap = {};
  cfgGet("safe_address", null, function (v1) { snap.safe = v1;
  cfgGet("safe_mode", "external", function (sm) { snap.safeMode = sm;
  cfgGet("clean_addr", null, function (cm) { try { var cb0 = cm ? JSON.parse(cm) : null; snap.cleanMx = cb0 ? cb0.mx : null; } catch (e) { snap.cleanMx = null; }
  cfgGet("enabled", "0", function (v2) { snap.rescueEnabled = (v2 === "1");
  cfgGet("auto_collect_safe", "0", function (v2b) { snap.autoCollectSafe = (v2b === "1");
  cfgGet("notify", "1", function (v3) { snap.notify = (v3 === "1");
  cfgGet("script_address", null, function (v4) { snap.scriptAddr = v4;
  cfgGet("last_action", null, function (la) { snap.lastAction = la;
  cfgGet("audit_at", null, function (aa) { snap.auditAt = aa ? Number(aa) : null;
  cfgGet("fc_status", "{}", function (stRaw) {
    var st = {}; try { st = JSON.parse(stRaw) || {}; } catch (e) { st = {}; }
    snap.lastTip = (st.lastTip != null) ? st.lastTip : null;
    snap.counts = st;
    cfgGet("fc_log", "[]", function (lgRaw) {
      var lg = []; try { lg = JSON.parse(lgRaw) || []; } catch (e) { lg = []; }
      snap.log = isArr(lg) ? lg : [];
      cfgGet("write_confirmed", null, function (wc) {
        snap.mode = (wc === "0") ? "READ" : "WRITE";
        cb(snap);
      });
    });
  }); }); }); }); }); }); }); }); }); });
}

// The node's own FutureCash/Maximize stakes (coins paying out to US), for the Lock-tab list.
// cb({tip, stakes:[{coinid, payout, amount, tokenid, matureBlock, ready}]}).
function listStakes(cb) {
  mcmd("block", function (b) {
    var tip = (b && b.response && parseInt(b.response.block, 10)) || 0;
    getFcScanAddresses(function (fcAddrs) {
      getAddressSets(function (sets) {
        var seen = {}, out = [];
        function scan(arr) {
          if (!isArr(arr)) return;
          for (var i = 0; i < arr.length; i++) {
            var c = arr[i];
            if (!c || !c.coinid || seen[c.coinid] || c.spent === true || !looksLikeFutureCash(c)) continue;
            var payout = getState(c, 2);
            if (!ownsAddress(sets.ownDefault, payout)) continue;   // only stakes paying to US
            seen[c.coinid] = true;
            var mb = toInt(getState(c, 1));
            out.push({ coinid: c.coinid, payout: payout, amount: coinOutAmount(c), tokenid: c.tokenid, matureBlock: mb, ready: (mb <= tip) });
          }
        }
        mcmd("coins relevant:true", function (r1) {
          scan(r1 && r1.response);
          eachSeries(fcAddrs, function (sa, idx, next) {
            mcmd("coins address:" + sa, function (r2) { scan(r2 && r2.response); next(); });
          }, function () { cb({ tip: tip, stakes: out }); });
        });
      });
    });
  });
}

/**
 * Future Cash guardian service entry (PURE ES5 — no async/await/Promise).
 * Concatenated after guardian.js at build time (build.sh) into a self-contained service.js.
 * Runs in the background whenever the node is up: audits (via the at-risk set the page writes),
 * detects matured FutureCash, collects safe ones (if opted in), collects+sweeps at-risk ones.
 */

function init() {
  ensureTables(function () {
    // Re-assert the contract script on every boot. Never gate this on the cached address: the cache
    // can survive a node restore that dropped the script, and without the script a collect builds an
    // invalid transaction that the chain silently rejects. registerFcScript checks the node's script
    // table first and only writes it when genuinely absent.
    registerFcScript(function (addr) {
      // Chain the two logs — logMsg is a read-modify-write on the shared fc_log, so firing both at
      // once would lose one of them.
      function started() {
        logMsg("info", "Future Cash guardian started", function () {
          mcmd("block", function (b) {
            var tip = b && b.response && parseInt(b.response.block, 10);
            if (tip) reconcile(tip);   // startup kick — resume in-flight work promptly
          });
        });
      }
      if (!addr) logMsg("error", "FutureCash contract script MISSING and could not be registered — collects will fail until this is fixed.", started);
      else started();
    });
  });
}

MDS.init(function (msg) {
  if (msg.event === "inited") {
    init();
  } else if (msg.event === "NEWBLOCK") {
    var tip = parseInt(msg.data.txpow.header.block, 10);
    if (tip) reconcile(tip);   // g_busy guards reentrancy
  } else if (msg.event === "NEWBALANCE") {
    cfgGet("last_tip", null, function (t) {
      var tip = parseInt(t, 10);
      if (tip) reconcile(tip);
    });
  }
});
