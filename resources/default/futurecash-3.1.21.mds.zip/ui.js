/**
 * Future Cash — page controller (loaded after guardian.js, which provides the callback API).
 * The PAGE runs the KeyUses audit (HTTP via MDS.net.GET) and writes the at-risk address set to
 * keypair (setAtRiskAddrs) for the background service; it also renders the guardian dashboard and
 * drives the Lock (create) form. All chain WRITES for collect/sweep happen in the service.
 */
var AUDIT_API = "https://eurobuddha.com/keyaudit";
var REUSE_API = "https://eurobuddha.com/reuse";
var APR_STORE = "https://eurobuddha.com/pandadapps.json"; // where AnyPhraseRecovery lives (hand-off)

var LAST_AUDIT = null;   // {atRisk:[], rows:[], anyRisk, maxReuse, tip}
var TIP = 0;

function $(id) { return document.getElementById(id); }
function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function escJs(s) { return String(s == null ? "" : s).replace(/\\/g, "\\\\").replace(/'/g, "\\'"); }
function shortA(s) { s = String(s || ""); return s.length > 18 ? s.slice(0, 10) + "…" + s.slice(-6) : s; }
function fmtAmt(a) { var n = Number(a); if (isNaN(n)) return String(a); return (n === Math.floor(n)) ? String(n) : n.toFixed(4).replace(/0+$/, "").replace(/\.$/, ""); }
function maturesInText(block, tip) {
  var blocks = Math.max(0, (block || 0) - (tip || 0)), mins = Math.round(blocks * 50 / 60);
  var when = mins < 90 ? mins + " min" : mins < 1440 ? Math.round(mins / 60) + " h" : Math.round(mins / 1440) + " days";
  return "in ~" + when + " (block " + block + ")";
}

var LAST_AUDIT_MS = 0;
var AUDIT_MIN_GAP = 90000;   // re-audit at most this often on NEWBLOCK (keeps the at-risk set fresh so
                             // the service's safe-collect gate stays valid without hammering the API)

MDS.init(function (msg) {
  if (msg.event === "inited") { boot(); }
  else if (msg.event === "NEWBLOCK") { try { TIP = parseInt(msg.data.txpow.header.block, 10) || TIP; } catch (e) {} refresh(); runAudit(false); if (typeof renderStakes === "function") renderStakes(false); }
  else if (msg.event === "NEWBALANCE") { refresh(); if (typeof renderStakes === "function") renderStakes(false); }
});

function boot() {
  storageSelfTest(function (ok) { if (!ok) toast("Warning: this node's keypair storage isn't persisting — settings may not save.", true); });
  MDS.cmd("block", function (b) { TIP = (b && b.response && parseInt(b.response.block, 10)) || 0; });
  setTab("guardian");
  // Re-assert the contract script on every page load too, so simply opening the app repairs a node
  // whose script went missing. Never swallow the result: a repair that fails silently is the same
  // class of bug as the missing script itself.
  registerFcScript(function (addr) {
    if (!addr) logMsg("warn", "Couldn't confirm the FutureCash contract script on this node — collecting a matured stake may fail. Reopen the app, or check the node is reachable.", function () {});
  });
  refresh();
  runAudit(true);           // audit on launch, as the user asked
  renderRecover();          // surface any coins stuck on retired addresses
  var lw = $("lockWhen"); if (lw) lw.min = toLocalInput(new Date());
  updateLockPreview();
  setInterval(refresh, 8000);
  setInterval(renderRecover, 30000);
}

/* ---------- Recover coins stuck on retired addresses ---------- */
function renderRecover() {
  var el = $("recoverBanner"); if (!el || typeof listRetiredWithCoins !== "function") return;
  listRetiredWithCoins(function (list) {
    var total = 0; (list || []).forEach(function (x) { total += x.coins; });
    if (!total) { el.className = "hidden"; el.innerHTML = ""; return; }
    el.className = "recover-banner";
    var addrs = (list || []).map(function (x) { return esc(shortA(x.addr)) + " · " + x.coins + " coin" + (x.coins === 1 ? "" : "s"); }).join("<br>");
    el.innerHTML = '<div class="rb-t">⚠ ' + total + ' coin' + (total === 1 ? "" : "s") + ' stuck on retired addresses</div>'
      + '<div class="rb-d">Retiring nulled those addresses’ keys, so normal sends can’t spend them (this also blocks other apps from sending). Recover moves them to your clean address using each address’s real key.</div>'
      + '<pre class="rb-addrs">' + addrs + '</pre>'
      + '<button class="btn danger" style="margin-top:10px" onclick="doRecover()">Recover ' + total + ' coin' + (total === 1 ? "" : "s") + '</button>';
  });
}
function doRecover() {
  if (!confirm("Recover all coins stuck on retired addresses to your clean same-node address?\n\nSigns with each address's real key. No coins leave your node.")) return;
  toast("Recovering stuck coins…");
  recoverRetiredCoins(function (r) {
    if (r && r.ok) toast("Recovered " + (r.recovered || 0) + " coin(s) from " + (r.addresses || 0) + " address(es) to your clean address.");
    else toast((r && r.error) || "Recovery failed", true);
    renderRecover(); refresh();
  });
}

/* ---------- Tabs ---------- */
function setTab(t) {
  var tabs = ["guardian", "lock", "activity", "help"];
  for (var i = 0; i < tabs.length; i++) {
    var on = tabs[i] === t;
    var v = $("view-" + tabs[i]); if (v) v.classList.toggle("hidden", !on);
    var b = $("tab-" + tabs[i]); if (b) b.classList.toggle("active", on);
  }
  if (t === "activity") refresh();
  if (t === "lock") { renderStakes(true); refreshPayoutInfo(); updateLockPreview(); }
}

/* ---------- Audit (page-side; writes at-risk set + freshness for the service) ----------
 * audit_ok=1 is set ONLY when BOTH /keyaudit AND /reuse returned usable data. On any failure we
 * set audit_ok=0 so the service will NOT bare-collect against an untrusted/partial verdict (it
 * either sweeps as a fail-safe, if rescue is configured, or waits). */
function runAudit(force) {
  if (!force && LAST_AUDIT_MS && (Date.now() - LAST_AUDIT_MS < AUDIT_MIN_GAP)) return;
  LAST_AUDIT_MS = Date.now();
  var el = $("auditStatus"); if (el) { el.className = "audit-status show"; el.textContent = "Auditing your 64 keys…"; }
  MDS.cmd("keys action:list", function (res) {
    if (!res || !res.status || !res.response || !res.response.keys) {
      cfgSet("audit_ok", "0", function () {});
      if (el) { el.className = "audit-status show err"; el.textContent = "Couldn't read your keys (keys action:list) — this dapp must run on your own node."; }
      return;
    }
    var localKeys = res.response.keys; // [{publickey, uses, ...}]
    var pubs = localKeys.map(function (k) { return k.publickey; }).join(",");
    MDS.net.GET(AUDIT_API + "?keys=" + encodeURIComponent(pubs), function (ar) {
      var data = parseNet(ar);
      if (!data || !data.keys) {
        cfgSet("audit_ok", "0", function () {});
        if (el) { el.className = "audit-status show err"; el.textContent = "Couldn't reach the audit service. Auto-collect of safe stakes is paused until it succeeds; your funds are untouched."; }
        return;
      }
      var keyRows = data.keys;
      var addrs = keyRows.filter(function (k) { return k.address; }).map(function (k) { return k.address; }).join(",");
      MDS.net.GET(REUSE_API + "?addrs=" + encodeURIComponent(addrs), function (rr) {
        var rd = parseNet(rr), reuseByAddr = {};
        var full = !!(rd && rd.results);   // reuse DB also answered => a complete, trustworthy audit
        if (full) rd.results.forEach(function (r) { if (r.address) reuseByAddr[String(r.address).toUpperCase()] = r; });
        classifyAndStore(localKeys, keyRows, reuseByAddr, data.archive_tip, full);
      });
    });
  });
}
function parseNet(res) {
  if (!res) return null;
  var b = res.response;
  if (typeof b === "string") { try { b = JSON.parse(b); } catch (e) { return null; } }
  return b || null;
}

function classifyAndStore(localKeys, keyRows, reuseByAddr, archiveTip, full) {
  var byPk = {};
  keyRows.forEach(function (u) { if (u && u.publickey) byPk[String(u.publickey).toUpperCase()] = u; });
  var atRiskAddrs = [], rows = [], anyRisk = false, maxReuse = 0;
  localKeys.forEach(function (k, i) {
    var local = Number(k.uses) || 0;
    var u = byPk[String(k.publickey).toUpperCase()] || {};
    var sigs = Number(u.spend_blocks || 0);
    var rinfo = u.address ? reuseByAddr[String(u.address).toUpperCase()] : null;
    var reused = !!(rinfo && rinfo.reused);
    var reuseCount = rinfo ? (Number(rinfo.reuse_count) || 0) : 0;
    var countRisk = sigs > local;                    // chain proves more sigs than the node counter
    var risk = reused || countRisk;
    if (risk) {
      anyRisk = true;
      if (u.address) atRiskAddrs.push(u.address);    // store BOTH forms so a hex OR Mx payout matches
      if (u.miniaddress) atRiskAddrs.push(u.miniaddress);
    }
    if (reuseCount > maxReuse) maxReuse = reuseCount;
    rows.push({ i: i + 1, addr: u.miniaddress || u.address || "(n/a)", local: local, sigs: sigs, risk: risk, reused: reused, reuseCount: reuseCount });
  });
  LAST_AUDIT = { atRisk: atRiskAddrs, rows: rows, anyRisk: anyRisk, maxReuse: maxReuse, archiveTip: archiveTip, full: full };
  // Hand the at-risk set to the background service (so it knows which payouts to sweep), then mark
  // the audit's success + freshness. audit_ok=1 ONLY on a COMPLETE audit (both APIs) — a partial one
  // can under-report reuse, so it must not license bare-collecting a "safe" coin.
  setAtRiskAddrs(atRiskAddrs, function () {
    cfgSet("audit_ok", full ? "1" : "0", function () {
      cfgSet("audit_at", "" + Date.now(), function () {
        cfgSet("audit_archive_tip", "" + (archiveTip || 0), function () { renderAudit(); renderHarden(); refresh(); });
      });
    });
  });
}

function renderAudit() {
  var el = $("auditStatus");
  if (!LAST_AUDIT) { if (el) { el.className = "audit-status"; } return; }
  if (el) {
    if (LAST_AUDIT.anyRisk) {
      var sev = LAST_AUDIT.maxReuse > 3 ? "err" : "warn";
      el.className = "audit-status show " + sev;
      el.textContent = "⚠ Key-reuse risk detected" + (LAST_AUDIT.maxReuse ? " (reused ×" + LAST_AUDIT.maxReuse + ")" : "") + ". At-risk stakes must be swept to a safe wallet.";
    } else if (!LAST_AUDIT.full) {
      // Partial audit (reuse DB unreachable): we can't fully clear you, so auto-collect of "safe"
      // stakes stays paused — but the at-risk sweep still runs on whatever risk we did see.
      el.className = "audit-status show warn";
      el.textContent = "Audit incomplete (reuse database unreachable). Safe auto-collect is paused until a full audit succeeds; at-risk rescue is unaffected.";
    } else {
      el.className = "audit-status show ok";
      el.textContent = "✓ No key-reuse risk. Your matured stakes can be collected safely.";
    }
  }
  // key table
  var box = $("keyTable");
  if (box && LAST_AUDIT.rows) {
    var h = '<table class="keys"><tr><th>#</th><th>Address</th><th>Node uses</th><th>On-chain</th><th>Status</th></tr>';
    LAST_AUDIT.rows.forEach(function (r) {
      var cls = r.reused ? (r.reuseCount > 3 ? "risk" : "warn") : (r.risk ? "warn" : "");
      var chip = r.reused ? ("RE-USED ×" + r.reuseCount) : (r.risk ? "AT RISK" : "ok");
      h += '<tr class="' + cls + '"><td>' + r.i + '</td><td class="mono">' + esc(shortA(r.addr)) + '</td><td>' + r.local + '</td><td>' + r.sigs + '</td><td>' + chip + '</td></tr>';
    });
    h += '</table>';
    box.innerHTML = h;
  }
}

/* ---------- Harden: retire reused addresses ---------- */
function renderHarden() {
  var panel = $("hardenPanel"); if (!panel) return;
  if (!LAST_AUDIT || !LAST_AUDIT.anyRisk || typeof listReusedDefaults !== "function") { panel.classList.add("hidden"); return; }
  listReusedDefaults(function (list) {
    if (!list.length) { panel.classList.add("hidden"); return; }
    var actives = list.filter(function (x) { return x.isDefault; });
    var retired = list.filter(function (x) { return !x.isDefault; });
    panel.classList.remove("hidden");
    var h = '<h3>Harden — retire reused addresses</h3>';
    h += '<p class="dim">These reused (at-risk) addresses of yours are still in the node\'s change rotation, so fresh change keeps landing on them. Retiring one drops it from that rotation for good — kept watch-only, moves no funds.</p>';
    var readyCount = 0;
    actives.forEach(function (x) {
      var empty = (x.coins === 0);
      if (empty) readyCount++;
      h += '<div class="retire-row"><div class="retire-a"><div class="mono">' + esc(shortA(x.mx || x.addr)) + '</div>'
        + (empty ? '<div class="dim2">empty · ready to retire</div>' : '<div class="warn-text">holds ' + x.coins + ' coin(s) — sweep them off first</div>')
        + '</div>'
        + (empty ? '<button class="btn danger sm" onclick="retireOne(\'' + escJs(x.addr) + '\')">Retire</button>' : '<button class="btn ok sm" onclick="sweepAddr(\'' + escJs(x.addr) + '\')">Sweep</button>')
        + '</div>';
    });
    if (!actives.length) h += '<div class="inline-msg ok">All your reused addresses are already retired from the change rotation. ✓</div>';
    if (retired.length) h += '<div class="dim2" style="margin-top:8px">✓ ' + retired.length + ' already retired (no longer a change address).</div>';
    if (readyCount > 1) h += '<button class="btn danger" style="margin-top:12px" onclick="retireAll()">Retire all ' + readyCount + ' empty</button>';
    h += '<p class="fineprint">Retiring survives node restarts but NOT a full reinstall-from-seed (these addresses derive from your seed and would return as defaults) — re-run this after any reseed. Tip: restart your node afterwards to top the change pool back up with fresh addresses.</p>';
    panel.innerHTML = h;
  });
}
function retireOne(addr) {
  if (!confirm("Retire this reused address? It will be dropped from your node's change rotation and kept watch-only. No funds move.")) return;
  retireAddress(addr, function (r) {
    if (r && r.ok) toast("Address retired — change will never land there again.");
    else toast((r && r.error) || "Retire failed", true);
    renderHarden();
  });
}
function sweepAddr(addr) {
  if (!confirm("Sweep every coin off this reused address to a fresh clean address on THIS node?\n\nIt signs once with the reused key to move them — recommended, since the address has already been reused. No coins leave your node.")) return;
  toast("Sweeping to a clean address…");
  sweepAddressToClean(addr, function (r) {
    if (r && r.ok) toast("Swept " + (r.swept || 0) + " coin(s) → clean " + shortA(r.dest || "") + ". You can retire it now.");
    else toast((r && r.error) || "Sweep failed", true);
    renderHarden();
  });
}
function retireAll() {
  if (!confirm("Retire ALL empty reused addresses from the change rotation? No funds move.")) return;
  listReusedDefaults(function (list) {
    var todo = list.filter(function (x) { return x.isDefault && x.coins === 0; });
    var i = 0, done = 0, failed = 0;
    (function nextOne() {
      if (i >= todo.length) { toast("Retired " + done + " address(es)" + (failed ? " · " + failed + " skipped" : "") + "."); renderHarden(); return; }
      var a = todo[i]; i++;
      retireAddress(a.addr, function (r) {
        if (r && r.ok) { done++; nextOne(); return; }
        failed++;
        // Stop the batch on a blocking condition (READ mode, pool floor) so we don't queue a pile of
        // pending actions or repeat a guaranteed failure; surface why.
        if (r && r.error && /READ mode|Pending|Keep at least|pool/i.test(r.error)) { toast(r.error, true); renderHarden(); return; }
        nextOne();
      });
    })();
  });
}

/* ---------- Dashboard ---------- */
function refresh() {
  if (typeof getSnapshot !== "function") return;
  getSnapshot(function (s) { updateModeBanner(s); renderDash(s); renderLog(s); });
}
// A guardian stuck in READ mode silently can't collect or sweep — surface it loudly, above the tabs,
// on every tab. Minima won't let a dapp self-elevate; only the user can grant WRITE in MiniHub.
function updateModeBanner(s) {
  var mb = $("modeBanner"); if (!mb) return;
  if (s && s.mode === "READ") {
    mb.className = "mode-banner";
    mb.innerHTML = '⚠ <b>READ mode — Future Cash cannot work like this.</b> This version runs as a background daemon: it watches your stakes and auto-collects them the moment they mature. In READ mode every action gets stuck as a "pending request" — and approving those by hand will not work, because the daemon must act unattended. Open <b>MiniHub → Future Cash</b> and switch it to <b>WRITE</b>. Prefer a fully manual app with no background daemon? <a href="https://eurobuddha.com/store/dapps/futurecash-2.7.1.mds.zip">Download classic Future Cash 2.7.1</a> (no key-reuse protection).';
  } else { mb.className = "mode-banner hidden"; mb.innerHTML = ""; }
}

function renderDash(s) {
  var c = s.counts || {};
  var safeN = c.readySafeN || 0, safeA = c.readySafeA || 0, riskN = c.readyRiskN || 0, riskA = c.readyRiskA || 0;
  var body = $("dashBody"); if (!body) return;
  var mode = s.mode === "READ" ? '<span class="pill warn">READ mode — switch to WRITE in MiniHub (pending approvals don\'t work)</span>' : '';
  var locked = (c.vaultLocked) ? '<span class="pill warn">🔒 vault locked — unlock to sweep</span>' : '';
  var audited = s.auditAt ? ("audited " + timeAgo(s.auditAt)) : "not audited yet";

  // A COMPLETE audit (both APIs) is enough to offer safe-collect — safety is decided PER COIN
  // (at_risk=0), so a coin paying to a clean address is collectable even if OTHER addresses are
  // reused. The engine still gates the actual collect on audit freshness.
  var auditUsable = !!(LAST_AUDIT && LAST_AUDIT.full);
  var html = '';
  var safeAction = '';
  // The auto-collect switch is offered even when nothing has matured yet. Previously it lived inside
  // `if (safeN)`, so a clean node had no route to arm the daemon up front — the switch only appeared
  // once money was already sitting there waiting.
  var safeDetail = safeN
    ? (fmtAmt(safeA) + " MINIMA in " + safeN + " matured stake" + (safeN === 1 ? "" : "s") + " on clean addresses.")
    : "No safe matured stakes right now.";
  if (s.autoCollectSafe) {
    safeDetail += " Auto-collect is <b>on</b> — matured stakes are collected to your own address whenever Future Cash is open. There's no rush: until then they stay safely locked away.";
    safeAction = '<span class="pill ok">auto-collect ON</span> <button class="btn ghost" onclick="toggleSafe(false)">Turn off</button>';
    if (safeN) safeAction += ' <button class="btn ghost" onclick="collectAllSafeNow()">Collect all now</button>';
  } else if (auditUsable) {
    safeDetail += " Turn on auto-collect and Future Cash will gather up your matured stakes to your own address each time you open it — no buttons to hunt for.";
    safeAction = '<button class="btn ok" onclick="toggleSafe(true)">Turn on auto-collect</button>';
    if (safeN) safeAction += ' <button class="btn ghost" onclick="collectAllSafeNow()">Collect ' + fmtAmt(safeA) + ' now</button>';
  } else {
    safeAction = '<span class="pill warn">run a full audit to enable auto-collect</span>';
  }
  html += card("safe", "Ready to collect — SAFE", safeDetail, safeAction);

  // At-risk ready card
  var pendRiskN = c.pendRiskN || 0, pendRiskA = c.pendRiskA || 0, pendSoonest = c.pendRiskSoonest || 0, curTip = c.lastTip || TIP;
  var riskDetail;
  if (riskN) {
    riskDetail = fmtAmt(riskA) + " MINIMA in " + riskN + " matured stake" + (riskN === 1 ? "" : "s") + " paying out to REUSED (at-risk) addresses — rescuing to safety now.";
  } else if (pendRiskN) {
    riskDetail = fmtAmt(pendRiskA) + " MINIMA in " + pendRiskN + " at-risk stake" + (pendRiskN === 1 ? "" : "s") + " maturing (soonest " + maturesInText(pendSoonest, curTip) + "). The guardian collects + sweeps each the moment it matures.";
  } else {
    riskDetail = (LAST_AUDIT && LAST_AUDIT.anyRisk) ? "No at-risk stakes right now — the guardian is watching and acts the moment one matures." : "No at-risk stakes detected.";
  }
  var riskAction = '';
  if (riskN || (LAST_AUDIT && LAST_AUDIT.anyRisk)) {
    var destTxt = s.safe ? (esc(shortA(s.safe)) + (s.safeMode === "samenode" ? " · this node" : " · external")) : "not set";
    if (s.rescueEnabled) {
      riskAction = '<div class="dest-row">rescue ON → <b>' + destTxt + '</b></div>'
        + '<button class="btn ghost sm" onclick="chooseFlowA()">Change destination</button> <button class="btn ghost sm" onclick="disableRescue()">Stop</button>';
    } else {
      riskAction = (s.safe ? '<div class="dest-row">destination: <b>' + destTxt + '</b></div>' : '')
        + '<button class="btn danger" onclick="chooseFlowA()">' + (s.safe ? 'Change / turn on rescue…' : 'Set up rescue…') + '</button>';
    }
  }
  html += card(riskN ? "risk" : "", "At-risk stakes", riskDetail, riskAction);

  // Status line
  var moving = (c.collecting || 0) + (c.sweeping || 0);
  var statusBits = [];
  if (c.watching) statusBits.push(c.watching + " stake" + (c.watching === 1 ? "" : "s") + " watched");
  if (moving) statusBits.push(moving + " collecting/sweeping (confirming on-chain)");
  if (c.swept) statusBits.push(c.swept + " secured to safe");
  if (c.collectedSafe) statusBits.push(c.collectedSafe + " collected");
  if (c.taken) statusBits.push('<span class="danger-text">' + c.taken + " need checking</span>");
  html += '<div class="statusline">' + (statusBits.join(" · ") || "idle") + '<br><span class="dim">' + esc(audited) + (s.lastTip ? " · block " + s.lastTip : "") + " " + mode + " " + locked + '</span></div>';

  body.innerHTML = html;
}
function card(kind, title, detail, action) {
  return '<div class="fcard ' + (kind || "") + '"><div class="fcard-t">' + esc(title) + '</div><div class="fcard-d">' + detail + '</div>' + (action ? '<div class="fcard-a">' + action + '</div>' : '') + '</div>';
}
function timeAgo(ms) {
  var d = Date.now() - Number(ms); if (isNaN(d) || d < 0) return "just now";
  var m = Math.floor(d / 60000); if (m < 1) return "just now"; if (m < 60) return m + "m ago";
  var h = Math.floor(m / 60); return h + "h ago";
}

/* ---------- Actions ---------- */
function toggleSafe(on) {
  setAutoCollectSafe(on, function () { toast(on ? "Collecting your safe matured stakes…" : "Stopped auto-collect."); refresh(); });
}
function disableRescue() { setRescueEnabled(false, function () { toast("At-risk rescue stopped."); refresh(); }); }

function openChooser() { $("chooser").classList.remove("hidden"); }
function closeChooser() { $("chooser").classList.add("hidden"); }

function chooseFlowA() {
  closeChooser();
  $("flowA").classList.remove("hidden");
  $("flowB").classList.add("hidden");
  var el = $("flowA"); if (el && el.scrollIntoView) { try { el.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (e) { el.scrollIntoView(); } }
}
function chooseFlowB() {
  closeChooser();
  $("flowB").classList.remove("hidden");
  $("flowA").classList.add("hidden");
}
function saveSafeAndEnable() {
  var addr = $("safeInput").value.trim();
  var msg = $("flowAmsg");
  setSafeAddress(addr, function (r) {
    if (!r || !r.ok) { msg.className = "inline-msg err"; msg.textContent = (r && r.error) || "Invalid address."; return; }
    setRescueEnabled(true, function (r2) {
      if (!r2 || !r2.ok) { msg.className = "inline-msg err"; msg.textContent = (r2 && r2.error) || "Couldn't enable rescue."; return; }
      msg.className = "inline-msg ok"; msg.textContent = "Rescue is ON → external wallet. Collected at-risk stakes will be swept there.";
      $("flowA").classList.add("hidden");
      refresh();
    });
  });
}
function useSameNodeSafe() {
  var msg = $("flowAmsg");
  msg.className = "inline-msg"; msg.textContent = "Minting a fresh clean address…";
  setSafeSameNode(function (r) {
    if (!r || !r.ok) { msg.className = "inline-msg err"; msg.textContent = (r && r.error) || "Couldn't set up a same-node address."; return; }
    setRescueEnabled(true, function (r2) {
      if (!r2 || !r2.ok) { msg.className = "inline-msg err"; msg.textContent = (r2 && r2.error) || "Couldn't enable rescue."; return; }
      msg.className = "inline-msg ok"; msg.textContent = "Rescue ON → fresh clean address on this node (" + shortA(r.address) + "). At-risk stakes will be collected + swept there.";
      $("flowA").classList.add("hidden");
      refresh();
    });
  });
}

/* ---------- Lock (create FutureCash) — date/time picker ---------- */
var BLOCK_MS = 50000;   // ~50s/block, the estimate used to convert a chosen time → target block
function nowMsUI() { return Date.now(); }
function toLocalInput(d) { function p(n) { return (n < 10 ? "0" : "") + n; } return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + "T" + p(d.getHours()) + ":" + p(d.getMinutes()); }
function parseWhen() { var el = $("lockWhen"); if (!el || !el.value) return 0; var ms = new Date(el.value).getTime(); return isNaN(ms) ? 0 : ms; }
function whenToBlocks(ms) { if (!ms || ms <= nowMsUI()) return 0; return Math.max(1, Math.round((ms - nowMsUI()) / BLOCK_MS)); }
function humanDur(ms) { var d = ms - nowMsUI(); if (d < 0) d = 0; var mins = Math.round(d / 60000); if (mins < 90) return mins + " min"; var hrs = Math.round(mins / 60); if (hrs < 48) return hrs + " h"; return Math.round(hrs / 24) + " days"; }
function fmtWhen(ms, full) {
  try { return new Date(ms).toLocaleString([], full ? { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" } : { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }); }
  catch (e) { return new Date(ms).toString(); }
}
function setLockPreset(mins) {
  var el = $("lockWhen"); if (el) el.value = toLocalInput(new Date(nowMsUI() + mins * 60000));
  updateLockPreview();
}
var LOCK_MODE = "date";
function setLockMode(mode) {
  LOCK_MODE = mode; var isDate = mode === "date";
  $("lockModeDate").classList.toggle("active", isDate);
  $("lockModeBlocks").classList.toggle("active", !isDate);
  $("lockPaneDate").classList.toggle("hidden", !isDate);
  $("lockPaneBlocks").classList.toggle("hidden", isDate);
  updateLockPreview();
}
function currentLockBlocks() {
  if (LOCK_MODE === "blocks") { var n = parseInt(($("lockBlocks").value || "").trim(), 10); return n > 0 ? n : 0; }
  var ms = parseWhen(); if (!ms || ms <= nowMsUI()) return 0; return whenToBlocks(ms);
}
function updateLockPreview() {
  var el = $("lockPreview"); if (!el) return;
  if (LOCK_MODE === "blocks") {
    var b = currentLockBlocks();
    if (!b) { el.textContent = "Enter how many blocks until it unlocks (~50s each)."; el.className = "preview dim2"; return; }
    var msb = nowMsUI() + b * BLOCK_MS;
    el.className = "preview";
    el.textContent = "Matures " + fmtWhen(msb, true) + " · block " + (TIP + b) + " · in ~" + humanDur(msb);
    return;
  }
  var ms = parseWhen();
  if (!ms) { el.textContent = "Pick when it unlocks — or tap a preset above."; el.className = "preview dim2"; return; }
  if (ms <= nowMsUI()) { el.textContent = "That time is in the past — pick a future time."; el.className = "preview errtext"; return; }
  el.className = "preview";
  el.textContent = "Matures " + fmtWhen(ms, true) + " · block " + (TIP + whenToBlocks(ms)) + " · in ~" + humanDur(ms);
}
function toggleRecipient() {
  $("recipientRow").classList.toggle("hidden", $("lockTo").value !== "someone");
  refreshPayoutInfo();
}
function refreshPayoutInfo() {
  var el = $("payoutInfo"); if (!el) return;
  if ($("lockTo").value === "someone") {
    var mx = ($("lockRecipient").value || "").trim();
    el.textContent = mx ? ("↳ pays to " + shortA(mx)) : "↳ enter the recipient's Mx address";
    return;
  }
  el.textContent = "↳ resolving your safe address…";
  if (typeof getOrMintCleanAddr !== "function") return;
  getOrMintCleanAddr(function (r) {
    if (r && r.ok) el.textContent = "↳ pays to your safe address " + shortA(r.mx) + " (this node)";
    else el.textContent = "↳ couldn't get a safe address" + (r && r.error ? " — " + r.error : "");
  });
}
var LOCK_BUSY = false;
function doLock() {
  if (LOCK_BUSY) return;   // guard against double-submit locking funds twice
  var amount = ($("lockAmount").value || "").trim();
  var to = $("lockTo").value;
  var msg = $("lockMsg"), btn = $("lockBtn");
  msg.className = "inline-msg"; msg.textContent = "";
  function fail(m) { msg.className = "inline-msg err"; msg.textContent = m; LOCK_BUSY = false; if (btn) btn.disabled = false; }
  function ok(m) { msg.className = "inline-msg ok"; msg.textContent = m; LOCK_BUSY = false; if (btn) btn.disabled = false; }
  if (!(Number(amount) > 0)) { fail("Enter a positive amount."); return; }
  var blocks = currentLockBlocks();
  if (!blocks) { fail(LOCK_MODE === "blocks" ? "Enter a block count (1 or more)." : "Pick a maturity date/time in the future."); return; }
  var ms = nowMsUI() + blocks * BLOCK_MS;   // approx maturity time, for the confirmation text
  LOCK_BUSY = true; if (btn) btn.disabled = true;
  msg.className = "inline-msg"; msg.textContent = "Creating stake… (approve it if your node asks)";
  function withPayout(hex, label) {
    createFutureCash(amount, "0x00", blocks, hex, ms, function (r) {
      if (r && r.ok) {
        ok("✓ Locked " + amount + " MINIMA → " + label + " · matures " + fmtWhen(r.maturityMs || ms) + " (block " + r.matBlock + "). It appears under Pending in a moment.");
        $("lockAmount").value = "";
        setTimeout(function () { renderStakes(true); }, 2000);
      } else { fail((r && r.error) || "Lock failed."); }
    });
  }
  if (to === "someone") {
    var rcp = ($("lockRecipient").value || "").trim();
    if (/^0x[0-9a-fA-F]{2,}$/.test(rcp)) { withPayout(rcp, shortA(rcp)); return; }   // already a 0x address
    if (!/^M[xX][0-9A-Za-z]+$/.test(rcp)) { fail("Enter the recipient's Mx (or 0x) address."); return; }
    MDS.cmd("checkaddress address:" + rcp, function (r) {
      var resp = r && r.response;                                          // checkaddress hex is under "0x" (or "original")
      var hex = resp && (resp["0x"] || resp.original || resp["0xaddress"] || resp.address);
      if (!hex || !/^0x/i.test(hex)) { fail("Couldn't resolve that recipient address."); return; }
      withPayout(hex, shortA(rcp));
    });
  } else {
    getOrMintCleanAddr(function (r) {
      if (!r || !r.ok) { fail((r && r.error) || "Couldn't get a safe payout address."); return; }
      withPayout(r.hex, "your safe address " + shortA(r.mx));
    });
  }
}

/* ---------- Your stakes (Lock tab) ---------- */
function isPayoutAtRisk(payout) {
  if (!LAST_AUDIT || !LAST_AUDIT.atRisk) return false;
  var p = String(payout || "").toLowerCase();
  for (var i = 0; i < LAST_AUDIT.atRisk.length; i++) { if (String(LAST_AUDIT.atRisk[i]).toLowerCase() === p) return true; }
  return false;
}
var STAKE_TAB = "pending";
function setStakeTab(which) {
  var isP = which === "pending"; STAKE_TAB = which;
  $("stakesTabPending").classList.toggle("active", isP);
  $("stakesTabMatured").classList.toggle("active", !isP);
  $("stakesTabPending").setAttribute("aria-selected", isP);
  $("stakesTabMatured").setAttribute("aria-selected", !isP);
  $("stakesPendingList").classList.toggle("hidden", !isP);
  $("stakesMaturedList").classList.toggle("hidden", isP);
}
function filterStakes() {
  var f = $("stakesFilter"); if (!f) return;
  var q = (f.value || "").trim().toLowerCase();
  ["stakesPendingList", "stakesMaturedList"].forEach(function (id) {
    var box = $(id); if (!box) return;
    var rows = box.querySelectorAll(".stake-row"), shown = 0;
    for (var i = 0; i < rows.length; i++) {
      var hit = !q || (rows[i].getAttribute("data-filter") || "").indexOf(q) > -1;
      rows[i].classList.toggle("hidden", !hit); if (hit) shown++;
    }
    var none = box.querySelector(".filter-none");
    if (q && rows.length && shown === 0) {
      if (!none) { none = document.createElement("div"); none.className = "stake-empty dim filter-none"; box.appendChild(none); }
      none.textContent = 'No stakes match "' + q + '".'; none.classList.remove("hidden");
    } else if (none) { none.classList.add("hidden"); }
  });
}
function renderStakes(force) {
  if (typeof listStakes !== "function") return;
  var pend = $("stakesPendingList"), mat = $("stakesMaturedList");
  if (!pend || !mat) return;
  if (force && !pend.querySelector(".stake-row")) pend.innerHTML = '<div class="stake-empty dim">Loading…</div>';
  listStakes(function (res) {
    var stakes = (res && res.stakes) || [], tip = (res && res.tip) || 0;
    var ready = [], pending = [];
    stakes.forEach(function (s) { (s.ready ? ready : pending).push(s); });
    pending.sort(function (a, b) { return a.matureBlock - b.matureBlock; });
    pend.innerHTML = pending.length ? pending.map(function (s) { return stakeRow(s, tip); }).join("") : '<div class="stake-empty dim">No pending stakes. Lock one below and it appears here.</div>';
    mat.innerHTML = ready.length ? ready.map(function (s) { return stakeRow(s, tip); }).join("") : '<div class="stake-empty dim">Nothing matured yet. The Guardian collects these automatically.</div>';
    $("stakeCountPending").textContent = pending.length;
    var mc = $("stakeCountMatured"); mc.textContent = ready.length; mc.classList.toggle("ok", ready.length > 0);
    filterStakes();
  });
}
function stakeRow(s, tip) {
  var risk = isPayoutAtRisk(s.payout);
  var unit = (s.tokenid === "0x00") ? "MINIMA" : "token";
  var amt = fmtAmt(s.amount), addr = shortA(s.payout);
  var when, whenCls = "stake-sub";
  if (s.ready) { when = "ready to collect"; whenCls += " ready"; }
  else {
    var blocks = Math.max(0, s.matureBlock - tip), mins = Math.round(blocks * 50 / 60);
    var human = mins < 90 ? mins + " min" : mins < 1440 ? Math.round(mins / 60) + " h" : Math.round(mins / 1440) + " days";
    when = "matures in ~" + human + " · block " + s.matureBlock;
  }
  // Manual collect: only for safe payouts backed by a fresh full audit (guardian re-checks both).
  // At-risk stakes stay on the rescue path — no bare-collect button for them.
  var action = "";
  if (s.ready && !risk) {
    var auditUsable = !!(LAST_AUDIT && LAST_AUDIT.full);
    action = auditUsable
      ? '<button class="btn ok sm" onclick="collectOne(\'' + escJs(s.coinid) + '\')">Collect now</button>'
      : '<button class="btn ghost sm" onclick="runAudit(true)">Re-audit to collect</button>';
  }
  var key = (amt + " " + unit + " " + s.payout + " " + addr).toLowerCase();
  return '<div class="stake-row' + (risk ? " at-risk" : "") + '" data-filter="' + esc(key) + '">'
    + '<div class="stake-main"><div class="stake-amt">' + esc(amt) + ' <span class="stake-unit">' + unit + '</span>'
    + (risk ? ' <span class="pill warn stake-flag">reused payout</span>' : '') + '</div>'
    + '<div class="' + whenCls + '">' + esc(when) + '</div></div>'
    + '<div class="stake-side"><span class="mono stake-addr">' + esc(addr) + '</span>'
    + (action ? '<div class="stake-act">' + action + '</div>' : '') + '</div></div>';
}

/* ---------- Manual collect ---------- */
function collectOne(coinid) {
  toast("Collecting…");
  collectStakeNow(coinid, function (r) {
    if (r && r.ok) {
      toast("Collect posted — confirms in about a block.");
      setTimeout(function () { renderStakes(true); refresh(); }, 2500);
    } else toast((r && r.error) || "Collect failed", true);
  });
}
function collectAllSafeNow() {
  listStakes(function (res) {
    var stakes = ((res && res.stakes) || []).filter(function (s) { return s.ready && !isPayoutAtRisk(s.payout); });
    if (!stakes.length) { toast("No safe matured stakes to collect."); return; }
    toast("Collecting " + stakes.length + " stake" + (stakes.length === 1 ? "" : "s") + "…");
    var i = 0, done = 0, failed = 0, lastErr = null;
    (function nextOne() {
      if (i >= stakes.length) {
        if (failed) toast("Posted " + done + " collect(s) · " + failed + " failed: " + (lastErr || ""), true);
        else toast("Posted " + done + " collect(s) — they confirm in about a block.");
        setTimeout(function () { renderStakes(true); refresh(); }, 2500);
        return;
      }
      var s = stakes[i]; i++;
      collectStakeNow(s.coinid, function (r) {
        if (r && r.ok) { done++; nextOne(); return; }
        failed++; lastErr = (r && r.error) || "unknown error";
        // A blocking condition (READ mode, stale audit) fails every remaining stake identically — stop.
        if (/READ mode|audit/i.test(lastErr)) { toast(lastErr, true); return; }
        nextOne();
      });
    })();
  });
}

/* ---------- Activity ---------- */
function shortTime(ts) { try { return new Date(ts).toLocaleTimeString(); } catch (e) { return ""; } }
var LOG_CACHE = [];
function renderLog(s) {
  var box = $("logBox"); if (!box) return;
  var lg = s.log || []; LOG_CACHE = lg;
  if (!lg.length) { box.innerHTML = '<div class="dim">No activity yet. Every collect, sweep and recovery shows here — with the full coin id, token, amount and addresses (copyable).</div>'; return; }
  var h = "";
  for (var i = 0; i < lg.length; i++) {
    var e = lg[i], msg = e.msg || "", cls = e.level === "error" ? "err" : e.level === "warn" ? "warn" : "";
    var icon = "·";
    if (/^(SWEPT|Secured|Collected|Recovered|Retired|Swept )/i.test(msg)) { icon = "✓"; if (!cls) cls = "ok"; }
    else if (/(posted|queued|Detected|Audit|Sweeping|Collecting)/i.test(msg)) icon = "→";
    if (/(TAKEN|fail|pending|couldn|error)/i.test(msg)) icon = "⚠";
    var parts = msg.split(" | "), summary = parts[0], detail = parts.length > 1 ? parts.slice(1).join("\n") : "";
    h += '<div class="logrow ' + cls + '"><div class="logtop"><span class="logi">' + icon + '</span><span class="logt">' + esc(shortTime(e.ts)) + '</span> <span class="logsum">' + esc(summary) + '</span>'
      + (detail ? ' <button class="logcopy" onclick="copyLog(' + i + ')">copy</button>' : '') + '</div>'
      + (detail ? '<pre class="logdetail">' + esc(detail) + '</pre>' : '') + '</div>';
  }
  box.innerHTML = h;
}
function copyLog(i) {
  var e = LOG_CACHE[i]; if (!e) return;
  copyText(String(e.msg || "").split(" | ").join("\n"));
  toast("Copied to clipboard");
}
function copyText(str) {
  try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(str); return; } } catch (e) {}
  try { var ta = document.createElement("textarea"); ta.value = str; ta.style.position = "fixed"; ta.style.opacity = "0"; document.body.appendChild(ta); ta.focus(); ta.select(); document.execCommand("copy"); document.body.removeChild(ta); } catch (e) {}
}
function doReset() {
  if (!confirm("Reset history? Clears completed records and counts (keeps in-flight rescues + your safe address). Moves no funds.")) return;
  clearAllState(function () { toast("History reset."); refresh(); });
}

/* ---------- toast ---------- */
var toastT = null;
function toast(m, isErr) {
  var el = $("toast"); if (!el) return;
  el.textContent = m; el.className = "toast show" + (isErr ? " err" : "");
  if (toastT) clearTimeout(toastT);
  toastT = setTimeout(function () { el.className = "toast"; }, 4200);
}
