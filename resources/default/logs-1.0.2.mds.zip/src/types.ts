export type LogsResponse = {
  ID: number;
  MESSAGE: string;
}[];
