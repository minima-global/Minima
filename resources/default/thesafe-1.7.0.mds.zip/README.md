###### The SAFE


#### Building the tailwindcss stylesheet..

- npm install -g tailwindcss
- npx tailwindcss build styles.css -o output.css

This is necessary if you do any changes to the main style sheet..


#### How to build minidapp

- zip -r thesafe-VERSION.mds.zip . -x "*.git*" "*.DS_Store" "*.gitignore" "*.zip" 

