import styles from "../../styling/Grid.module.css";
const MiGrid = () => {
  return <div className={styles["app-grid"]}></div>;
};

export default MiGrid;
