
##### [1.14.0] - 14 Mar 2025

- Removed legacy stuff


##### [1.13.1] - 19 Feb 25

- Minor text updates
- Fixed validation issues on the QuickSync and Restore from Seed Phrase dialogs on page load

##### [1.13.0] - 18 Feb 25

- Added overflow-x hidden on body to prevent scrollbar from appearing
- Added the ability to navigate to a specific page via url when the app is loaded

##### [1.12.0] - 18 Dec 24

- Disable the ability to QuickSync when the vault is locked

##### [1.10.0] - 27 Aug 24

- Add support for URLs for QuickSync
- Design & UX Tweak on QuickSync dialog

##### [1.9.3] - 26 June 24

- Restore from backup error msg

##### [1.9.2] - 24 June 24

- Restore from backup when no host selected
- Make Confirm pwd disabled on Create Backup

##### [1.9.0] - 03 June 24

- Feedback changes

##### [1.8.2] - 21 May 24

- Add cli logs to Dialog
- Add spartacusrex default host ip for a placeholder

##### [1.8.0] - 20 May 24

- Tweak design of home page
- Added legacy opts for Archive Reset & Restore from backup
- Added new feature "Restore node"

##### [1.1.0] - 11 December 23

- Key down while clicked in a seed phrase input element will open suggestions
- You can now arrow-down/arrow-up through suggestions
- Pressing enter key/tab key will select your highlighted suggestion whilst in arrow mode
- Tab will select your highlighted & move you to next input
- Pressing Escape key will close the suggestions window

