##### [0.8.4] - 28 November 23

- Updated source code
- Added tailwindcss
- Updated home page
- New icons

##### [0.9.1] - 06 December 23

- Fix callback on Pending dialog
- Add error message on error dialog
- Re-enable Create Vault button on error

##### [0.9.2] - 06 December 23

- Fix callback on Pending dialog for Unlocking vault

##### [0.9.2] - 11 December 23

- Confirm Lock Phrase field
- Validate characters & equality
- Updated Vault Icon