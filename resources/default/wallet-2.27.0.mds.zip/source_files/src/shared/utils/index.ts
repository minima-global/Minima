export * from './getTxPOWDetailsType';
