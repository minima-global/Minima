# Changelog


##### [0.9.0] - 27 February 25
- Updated icon (not beta)

##### [0.8.0] - 05 February 25
- Remove node locked and instead send to pending command
- Remove pre-requisite of having to have an unlocked node & in write mode on the Help section


##### [0.7.2] - 04 February 25
- Added pending for signatures
- Fixed copy in Help
- Clean up QR Reader on component un-mount

##### [0.6.0] - 29 Jan 25
- Switch Vault call to Status

##### [0.5.0] - 28 Jan 24

- Decrease Axe S3 icon size
- Line height & font size changes on Intro screen
- Token ID / QR data truncation fix on inputs
- Fixed copy for vault locked
- Give more height to progressive dialogs
- Add a "Scanned QR code" progression copy
- Copy changes
