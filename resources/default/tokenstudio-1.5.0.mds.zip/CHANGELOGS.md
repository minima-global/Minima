# Changelog

##### [0.5.0] - 25 September 24

- First release

##### [1.0.0] - 24 January 25

- switch light and dark mode copy
- added desktop drop down ui 
- switch off hover on add image pad when image is selected
- fix line height on getting started page

##### [1.1.0] - 27 January 25

- Node locked check
- Make extra metadata more lenient
- design tweak

##### [1.2.0] - 28 January 25

- Update copy on review page

##### [1.3.0] - 29 January 25

- Update copy on image upload
- Add correct decimals to copy CLI for custom & simple tokens 

##### [1.4.2] - 26 February 25

- Fix bug on space error in name for simple tokens
- Added external_url default property for NFTs
- 
- ##### [1.5.0] - 27 February 25

- Fix description input fields
- Tweak text color on light mode
