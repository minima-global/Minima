export const systemApps = ['Settings', 'Health', 'Logs', 'Security', 'Dapp Store'];
export const excludedFromFolders = ['Pending'];