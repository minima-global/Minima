function Install() {
  return <div />;
}

export default Install;
