function Delete() {
  return <div />;
}

export default Delete;
