import { useEffect, useState } from 'react';
import { get, loadBinary, set } from '../lib';

/**
 * Sets the correct wallpaper based on user settings
 * @returns {{setActiveWallpaper: (value: (((prevState: string) => string) | string)) => void, activeWallpaper: string}}
 */
function useWallpaper(loaded: boolean) {
  const [activeWallpaper, setActiveWallpaper] = useState('');

  useEffect(() => {
    const activeWallpaper = localStorage.getItem('__miniHub_bg');

    if (activeWallpaper) {
      set('BACKGROUND', activeWallpaper).then(() => {
        localStorage.removeItem('__miniHub_bg');
      });
    }
  });

  useEffect(() => {
    if (loaded) {
      get('BACKGROUND').then(async (response) => {
        const activeWallpaper = response as string;

        if (activeWallpaper) {
          document.body.classList.value = '';

          if (activeWallpaper.includes('custom-')) {
            const filePath = `/my_wallpapers/${activeWallpaper.split('-')[1]}`
            const file = await loadBinary(filePath);
            const ext =  /(?:\.([^.]+))?$/g.exec(file.name)![1];
            const base64 = MDS.util.hexToBase64(file.data);

            document.body.classList.add(`bg-custom`);
            const data = `data:image/${ext};base64,${base64}`;
            document.body.style.backgroundImage = `url("${data}")`;
            setActiveWallpaper(activeWallpaper);

          } else {

            /**
             * Set preloaded wallpaper if custom one hasn't been selected
             */
            if (activeWallpaper.includes('thumbnail-')) {
              document.body.classList.add(`bg-${activeWallpaper.replace('thumbnail-', '')}`);
            } else {
              document.body.classList.add(`bg-${activeWallpaper}`);
            }

            setActiveWallpaper(activeWallpaper);
          }
        }
      });
    }
  }, [activeWallpaper, loaded]);

  useEffect(() => {
    if (activeWallpaper !== '') {
      document.body.classList.value = '';

      if (activeWallpaper.includes('thumbnail-')) {
        document.body.classList.add(`bg-${activeWallpaper.replace('thumbnail-', '')}`);
      } else {
        document.body.classList.add(`bg-${activeWallpaper}`);
      }
    }
  }, [activeWallpaper]);

  return {
    activeWallpaper,
    setActiveWallpaper,
  };
}

export default useWallpaper;
